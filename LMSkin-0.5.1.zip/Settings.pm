package Plugins::LMSkin::Settings;

# LMSkin - settings page (Settings > Advanced > LMSkin).
#
# Every pref listed here becomes a form field on the template, using the
# pref_<name> naming LMS expects.

use strict;

use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

my $prefs = preferences('plugin.lmskin');

sub name {
    return 'PLUGIN_LMSKIN';
}

sub page {
    return 'plugins/LMSkin/settings/basic.html';
}

sub prefs {
    return ($prefs, qw(gridSize pageSize setPlayerLibrary accent blur
                       aiEnabled aiBaseUrl aiApiKey aiModel aiTemperature aiMaxCandidates aiTimeout
                       aiOnlineResolve aiOnlineQobuz aiOnlineTidal aiOnlineSpotty aiOnlineLimit
                       lastfmApiKey lbEnabled lbToken lbUser));
}

1;

__END__
