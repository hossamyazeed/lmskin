package Plugins::LMSkin::PlayLog;

# Wrapped's listening log. LMS has no play *time* tracking (only
# tracks_persistent counters), so this keeps its own SQLite log:
# one row per played track with listened-ms, skip detection and source.
#
#   <cachedir>/lmskin/plays.db   (WAL)
#
# Hooks: playlist newsong (flush previous + open new), pause, stop. A 15 s
# heartbeat accumulates listened time for every playing player. A row is only
# written when at least 5 s were listened to, so false starts never appear.

use strict;

use DBI;
use Encode;
use File::Path qw(make_path);
use File::Spec;
use JSON::XS qw(encode_json);
use Time::Local qw(timelocal);
use Slim::Control::Request;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Player::Client;
use Slim::Player::Playlist;
use Slim::Player::ProtocolHandlers;
use Slim::Player::Sync;
use Slim::Schema;
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;
use Time::HiRes;

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.lmskin',
    'defaultLevel' => 'ERROR',
    'description'  => 'PLUGIN_LMSKIN'
});

my $serverprefs = preferences('server');
my $lmprefs     = preferences('plugin.lmskin');

my $TICK_OBJ  = bless {}, 'Plugins::LMSkin::PlayLog::Timer';
my $PRUNE_OBJ = bless {}, 'Plugins::LMSkin::PlayLog::Timer';

my $dbh;
my %CURRENT;    # playerId => { ...row, listened_ms, last_tick }
my $RETENTION = 730 * 24 * 60 * 60;    # 24 months

# ---------------------------------------------------------------- lifecycle

sub init {
    _dbh();    # create the db + schema eagerly so early plays are not lost
    _arm_tick();
    _arm_prune();
}

sub shutdown {
    for my $id (keys %CURRENT) {
        my $client = Slim::Player::Client::getClient($id);
        _flush($client) if $client;
    }
    %CURRENT = ();
    Slim::Utils::Timers::killTimer($TICK_OBJ);
    Slim::Utils::Timers::killTimer($PRUNE_OBJ);
    if ($dbh) {
        eval { $dbh->disconnect };
        $dbh = undef;
    }
}

sub _db_path {
    my $root = $serverprefs->get('cachedir') || Slim::Utils::Prefs::dir();
    my $dir  = File::Spec->catdir($root, 'lmskin');
    make_path($dir) unless -d $dir;
    return File::Spec->catfile($dir, 'plays.db');
}

sub _dbh {
    return $dbh if $dbh;
    $dbh = DBI->connect(
        'dbi:SQLite:dbname=' . _db_path(), '', '',
        { RaiseError => 1, PrintError => 0, sqlite_unicode => 1, AutoCommit => 1 },
    );
    $dbh->do('PRAGMA journal_mode=WAL');
    $dbh->do(q{
        CREATE TABLE IF NOT EXISTS plays (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            player      TEXT,
            track_id    INTEGER,
            url         TEXT,
            title       TEXT,
            artist      TEXT,
            album_id    INTEGER,
            coverid     TEXT,
            started     INTEGER,
            listened_ms INTEGER,
            source      TEXT,
            skipped     INTEGER
        )
    });
    $dbh->do('CREATE INDEX IF NOT EXISTS idx_plays_started ON plays(started)');
    $dbh->do('CREATE INDEX IF NOT EXISTS idx_plays_track   ON plays(track_id)');
    return $dbh;
}

# ---------------------------------------------------------------- hooks

sub on_new_song {
    my $request = shift;
    my $client  = $request->client() or return;
    if ($client->isSynced()) {
        return unless Slim::Player::Sync::isMaster($client);
    }
    _flush($client);

    # playingSong is not reliable at newsong time (mid-transition); resolve
    # the track the way AudioScrobbler does.
    my $url   = Slim::Player::Playlist::url($client) or return;
    my $track = Slim::Schema->objectForUrl({ url => $url }) or return;

    my $url    = $track->url || '';
    my $source = $track->remote ? 'remote'
               : $url =~ m{^https?://} ? 'radio'
               : 'local';

    my $coverid = $track->coverid;
    if ($track->remote) {
        my $art;
        if (my $handler = Slim::Player::ProtocolHandlers->handlerForURL($url)) {
            if ($handler->can('getMetadataFor')) {
                my $meta = eval { $handler->getMetadataFor($client, $url, undef, $track) };
                $art = $meta->{cover} || $meta->{icon} if ref $meta eq 'HASH';
            }
        }
        $art ||= eval { $track->cover };
        $coverid = $art || '';
    }
    $coverid = '' if defined $coverid && $coverid =~ /^-/;

    $CURRENT{ $client->id } = {
        player      => $client->name || $client->id,
        track_id    => $track->id,
        url         => $url,
        title       => _t($track->title),
        artist      => _t((eval { $track->artist->name } || '')),
        album       => _t((eval { $track->album->title } || '')),
        album_id    => $track->albumid,
        coverid     => $coverid,
        started     => time(),
        listened_ms => 0,
        last_tick   => Time::HiRes::time(),
        secs        => $track->secs || 0,
        source      => $source,
    };
}

sub on_pause {
    my $request = shift;
    my $client  = $request->client() or return;
    _tick_client($client);    # accumulate up to the pause moment, then freeze
}

sub on_stop {
    my $request = shift;
    my $client  = $request->client() or return;
    _flush($client);
}

# ---------------------------------------------------------------- accumulation

sub _arm_tick {
    Slim::Utils::Timers::setTimer($TICK_OBJ, time() + 15, \&_tick);
}

sub _tick {
    for my $client (Slim::Player::Client::clients()) {
        next unless $client && $client->isPlaying;
        _tick_client($client);
    }
    _arm_tick();
}

sub _tick_client {
    my $client = shift;
    my $id     = $client->id;
    my $cur    = $CURRENT{$id} or return;
    my $now    = Time::HiRes::time();
    $cur->{listened_ms} += ($now - $cur->{last_tick}) * 1000;
    $cur->{last_tick} = $now;
}

sub _flush {
    my $client = shift;
    my $id     = $client->id;
    my $cur    = delete $CURRENT{$id} or return;

    my $now = Time::HiRes::time();
    $cur->{listened_ms} += ($now - $cur->{last_tick}) * 1000 if $client->isPlaying;

    return if $cur->{listened_ms} < 5000;

    my $secs = $cur->{secs} || 0;
    my $skipped = ($secs > 0 && $cur->{listened_ms} < 0.4 * 1000 * $secs) ? 1 : 0;

    eval {
        _dbh()->do(
            'INSERT INTO plays (player, track_id, url, title, artist, album_id, coverid, started, listened_ms, source, skipped)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            undef,
            $cur->{player}, $cur->{track_id}, $cur->{url}, $cur->{title}, $cur->{artist},
            $cur->{album_id}, $cur->{coverid}, $cur->{started},
            int($cur->{listened_ms}), $cur->{source}, $skipped,
        );
    } or do {
        $log->error("playlog insert failed: $@");
    };

    _scrobble_listenbrainz($cur) if !$skipped;
}

# ---------------------------------------------------------------- listenbrainz

my $LB_URL = 'https://api.listenbrainz.org/1/submit-listens';
my $lbUserResolved;

# Best-effort dual-scrobbling: AudioScrobbler owns Last.fm, we submit to
# ListenBrainz from the same flush. The username is resolved once from the
# token (validate-token) when not configured explicitly.
sub _scrobble_listenbrainz {
    my $cur = shift;

    return unless $lmprefs->get('lbEnabled');
    my $token = $lmprefs->get('lbToken') || '';
    return if $token eq '';
    return if !$cur->{title} || !$cur->{artist};

    my $user = $lmprefs->get('lbUser') || '';
    if ($user eq '') {
        $user = $lbUserResolved ||= _lb_validate_user($token);
        return if $user eq '';
    }

    my $meta = {
        track_name  => $cur->{title},
        artist_name => $cur->{artist},
    };
    $meta->{release_name} = $cur->{album} if $cur->{album};
    $meta->{additional_info} = {
        media_player       => 'LMS/LMSkin',
        submission_client  => 'lmskin-playlog',
    };

    my $body = encode_json({
        listen_type => 'single',
        payload     => [ {
            listened_at    => $cur->{started},
            track_metadata => $meta,
        } ],
    });

    Slim::Networking::SimpleAsyncHTTP->new(
        sub { },    # fire and forget
        sub {
            my $res = shift;
            $log->warn('listenbrainz submit failed (HTTP ' . (eval { $res->code } || '?') . ')');
        },
        { timeout => 15 },
    )->post($LB_URL,
        'Content-Type'  => 'application/json',
        'Authorization' => 'Token ' . $token,
        $body,
    );
}

sub _lb_validate_user {
    my ($token) = @_;
    my $user = '';
    my $done = 0;

    my $http = Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $res = shift;
            my $data = eval { JSON::XS::decode_json($res->content) };
            $user = $data->{user_name} if ref $data eq 'HASH' && $data->{valid};
            $done = 1;
        },
        sub { $done = 1; },
        { timeout => 10 },
    );
    $http->get('https://api.listenbrainz.org/1/validate-token',
        'Authorization' => 'Token ' . $token);

    # Tiny sync wait: validation happens once per process lifetime.
    for (1 .. 50) {
        last if $done;
        select(undef, undef, undef, 0.1);
    }
    return $user;
}

sub _t {
    my $v = shift // '';
    return Encode::decode_utf8($v) if !Encode::is_utf8($v);
    return $v;
}

# ---------------------------------------------------------------- pruning

sub _arm_prune {
    Slim::Utils::Timers::setTimer($PRUNE_OBJ, time() + 3600, \&_prune);
}

sub _prune {
    eval {
        _dbh()->do('DELETE FROM plays WHERE started < ?', undef, time() - $RETENTION);
    };
    _arm_prune();
}

# ---------------------------------------------------------------- stats

my %RANGES = (
    '30d'     => sub { time() - 30 * 86400 },
    '90d'     => sub { time() - 90 * 86400 },
    'month'   => sub { my @l = localtime; return timelocal(0, 0, 0, 1, $l[4], $l[5]) },
    'quarter' => sub { my @l = localtime; return timelocal(0, 0, 0, 1, int($l[4] / 3) * 3, $l[5]) },
    'year'    => sub { my @l = localtime; return timelocal(0, 0, 0, 1, 0, $l[5]) },
    'all'     => sub { 0 },
);

sub _cutoff {
    my $range = shift || 'month';
    my $code = $RANGES{$range} || $RANGES{'month'};
    return $code->();
}

sub stats {
    my ($range) = @_;
    my $from = _cutoff($range);
    my $d = _dbh();

    my $head = $d->selectrow_hashref(
        'SELECT COUNT(*) AS plays,
                COUNT(DISTINCT track_id) AS tracks,
                COUNT(DISTINCT artist)   AS artists,
                COUNT(DISTINCT album_id) AS albums,
                COUNT(DISTINCT date(started, "unixepoch")) AS active_days,
                COALESCE(SUM(listened_ms),0) AS listened_ms,
                COALESCE(SUM(CASE WHEN skipped = 1 THEN 1 ELSE 0 END),0) AS skips,
                COALESCE(SUM(CASE WHEN source = "radio"  THEN listened_ms ELSE 0 END),0) AS radio_ms,
                COALESCE(SUM(CASE WHEN source != "radio" THEN listened_ms ELSE 0 END),0) AS music_ms
           FROM plays WHERE started >= ?', undef, $from) || {};

    my $replays = ($head->{plays} || 0) - ($head->{tracks} || 0);
    $replays = 0 if $replays < 0;

    my @top_tracks = @{
        $d->selectall_arrayref(
            'SELECT title, artist, track_id, coverid, COUNT(*) AS plays, SUM(listened_ms) AS ms
               FROM plays WHERE started >= ? AND track_id IS NOT NULL
              GROUP BY track_id ORDER BY plays DESC, ms DESC LIMIT 10',
            { Slice => {} }, $from) || []
    };
    my @top_artists = @{
        $d->selectall_arrayref(
            'SELECT artist, COUNT(*) AS plays FROM plays
              WHERE started >= ? AND artist != ""
              GROUP BY artist ORDER BY plays DESC LIMIT 10',
            { Slice => {} }, $from) || []
    };
    my @top_albums = @{
        $d->selectall_arrayref(
            'SELECT album_id, COUNT(*) AS plays FROM plays
              WHERE started >= ? AND album_id IS NOT NULL
              GROUP BY album_id ORDER BY plays DESC LIMIT 10',
            { Slice => {} }, $from) || []
    };

    # Resolve album titles/covers through the library db.
    my %album_meta;
    if (@top_albums) {
        my $lib = eval { Slim::Schema->dbh } or undef;
        if ($lib) {
            my $ids = join(',', map { int($_->{album_id}) } @top_albums);
            my $rows = $lib->selectall_arrayref(
                "SELECT id, title, artwork FROM albums WHERE id IN ($ids)", { Slice => {} });
            %album_meta = map { $_->{id} => $_ } @{ $rows || [] };
        }
    }

    my @hours = (0) x 24;
    my $hrows = $d->selectall_arrayref(
        'SELECT CAST(strftime("%H", started, "unixepoch") AS INTEGER) AS h, SUM(listened_ms) AS ms
           FROM plays WHERE started >= ? GROUP BY h', { Slice => {} }, $from);
    $hours[ $_->{h} ] = int(($_->{ms} || 0) / 60000) for @{ $hrows || [] };

    my @recent = @{
        $d->selectall_arrayref(
            'SELECT * FROM plays WHERE started >= ? ORDER BY started DESC LIMIT 10',
            { Slice => {} }, $from) || []
    };

    my $plays = $head->{plays} || 0;
    return {
        hours       => sprintf('%.1f', ($head->{listened_ms} || 0) / 3600000),
        plays       => $plays,
        tracks      => $head->{tracks} || 0,
        artists     => $head->{artists} || 0,
        albums      => $head->{albums} || 0,
        active_days => $head->{active_days} || 0,
        skip_pct    => $plays ? sprintf('%.0f', 100 * ($head->{skips} || 0) / $plays) : 0,
        replay_pct  => $plays ? sprintf('%.0f', 100 * $replays / $plays) : 0,
        music_min   => int(($head->{music_ms} || 0) / 60000),
        radio_min   => int(($head->{radio_ms} || 0) / 60000),
        top_tracks  => [ map { _u($_) } @top_tracks ],
        top_artists => [ map { _u($_) } @top_artists ],
        top_albums  => [ map { _u({ %$_, title => ($album_meta{ $_->{album_id} } || {})->{title} || '', art => ($album_meta{ $_->{album_id} } || {})->{artwork} || '' }) } @top_albums ],
        hours_loop  => \@hours,
        recent      => [ map { _u($_) } @recent ],
    };
}

sub _u {
    my $row = shift;
    for my $k (keys %$row) {
        $row->{$k} = _t($row->{$k}) if defined $row->{$k} && !ref $row->{$k};
    }
    return $row;
}

sub history {
    my (%opt) = @_;
    my $from  = _cutoff($opt{range} || 'all');
    my $limit = $opt{limit} || 50;
    $limit = 1 if $limit < 1;
    $limit = 200 if $limit > 200;
    my $offset = $opt{offset} || 0;

    my $d = _dbh();
    my $total = $d->selectrow_array('SELECT COUNT(*) FROM plays WHERE started >= ?', undef, $from) || 0;
    my $rows = $d->selectall_arrayref(
        'SELECT * FROM plays WHERE started >= ? ORDER BY started DESC LIMIT ? OFFSET ?',
        { Slice => {} }, $from, $limit, $offset) || [];
    return (total => $total, rows => [ map { _u($_) } @$rows ]);
}

sub clear {
    _dbh()->do('DELETE FROM plays');
}

sub count {
    return _dbh()->selectrow_array('SELECT COUNT(*) FROM plays') || 0;
}

1;

__END__
