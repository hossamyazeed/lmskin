package Plugins::LMSkin::Ai;

# Studio: natural-language playlist generation grounded in the real library.
#
# Two grounding modes, chosen by pool size:
#   library — pool <= aiMaxCandidates: the model picks ids from the actual
#             candidate list, so every returned id exists by construction.
#   free    — pool too big: the model invents artist/title/album/year, and we
#             match them back with a normalized ladder (found/uncertain/missing).
#
# Provider calls are async (SimpleAsyncHTTP) with an in-memory job registry
# (30 min TTL). Never block a JSON-RPC request on the model.

use strict;

use Encode;
use File::Spec;
use JSON::XS qw(decode_json encode_json);
use List::Util qw(shuffle);
use Scalar::Util qw(blessed);
use URI::Escape qw(uri_escape_utf8);
use Slim::Control::Request;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Player::Client;
use Slim::Schema;
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Slim::Utils::Timers;

my $log  = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.lmskin',
    'defaultLevel' => 'ERROR',
    'description'  => 'PLUGIN_LMSKIN'
});
my $prefs = preferences('plugin.lmskin');

my %JOBS;        # id => { id, status, mode, pool, dropped, title, tracks=>[], error, created }
my $JOB_SEQ = 0;
my $TTL     = 30 * 60;
my $SWEEP_OBJ = bless {}, 'Plugins::LMSkin::Ai::Timer';
my $lbUserResolvedCharts;

# ---------------------------------------------------------------- entry point

my $started;

sub handle {
    my ($cmd, $request) = @_;

    init() unless $started;

    if ($cmd eq 'ai-generate')     { _generate($request);     return; }
    if ($cmd eq 'ai-result')       { _result($request);       return; }
    if ($cmd eq 'ai-replace')      { _replace($request);      return; }
    if ($cmd eq 'ai-play')         { _play($request);         return; }
    if ($cmd eq 'ai-save')         { _save($request);         return; }
    if ($cmd eq 'ai-cancel')       { _cancel($request);       return; }
    if ($cmd eq 'charts-generate') { _charts_generate($request); return; }

    $request->setStatusBadParams();
}

sub init {
    return if $started;
    $started = 1;
    Slim::Utils::Timers::setTimer($SWEEP_OBJ, time() + 300, \&_sweep);
}

sub _sweep {
    my $now = time();
    foreach my $id (keys %JOBS) {
        delete $JOBS{$id} if $now - $JOBS{$id}{created} > $TTL;
    }
    Slim::Utils::Timers::setTimer($SWEEP_OBJ, time() + 300, \&_sweep);
}

# ---------------------------------------------------------------- generation

sub _generate {
    my $request = shift;

    if (!$prefs->get('aiEnabled')) {
        $request->addResult('error', 'AI studio is disabled in settings');
        $request->setStatusDone();
        return;
    }
    if (!($prefs->get('aiModel') || '')) {
        $request->addResult('error', 'AI model not configured — set base URL, API key and model in LMSkin settings');
        $request->setStatusDone();
        return;
    }

    my %f = (
        prompt   => substr($request->getParam('prompt') // '', 0, 2000),
        genre    => $request->getParam('genre')    // '',
        decade   => $request->getParam('decade')   // '',
        energy   => $request->getParam('energy')   // '',
        language => $request->getParam('language') // '',
        count    => _clamp($request->getParam('count'), 5, 100, 20),
        mode     => $request->getParam('mode') // 'auto',
    );

    if (!$f{prompt} && !$f{genre} && !$f{decade}) {
        $request->addResult('error', 'Give a prompt or pick at least one filter');
        $request->setStatusDone();
        return;
    }

    my $pool = _build_pool(\%f);
    my $mode = $f{mode};
    $mode = ($pool->{total} <= _int($prefs->get('aiMaxCandidates'), 800)) ? 'library' : 'free' if $mode eq 'auto';

    my $job = {
        id      => ++$JOB_SEQ,
        status  => 'running',
        mode    => $mode,
        pool    => $pool->{total},
        dropped => $pool->{dropped},
        tracks  => [],
        error   => '',
        created => time(),
    };

    if ($mode eq 'library' && !$pool->{total}) {
        $job->{status} = 'error';
        $job->{error}  = 'No tracks match the filters';
    } else {
        $JOBS{ $job->{id} } = $job;
        _start_job($job, \%f, $pool->{rows});
    }

    $request->addResult('job',    $job->{id} // 0);
    $request->addResult('status', $job->{status});
    $request->addResult('mode',   $job->{mode});
    $request->addResult('pool',   $job->{pool});
    $request->addResult('dropped', $job->{dropped});
    $request->setStatusDone();
}

sub _start_job {
    my ($job, $f, $pool) = @_;

    my $messages = $job->{mode} eq 'library'
        ? [ { role => 'system', content => _system_msg() }, { role => 'user', content => _library_prompt($f, $pool) } ]
        : [ { role => 'system', content => _system_msg() }, { role => 'user', content => _free_prompt($f) } ];

    _call_provider($job, $messages, 1);
}

sub _system_msg {
    return 'You are a precise music curator for a personal music library. Answer with JSON only, no prose.';
}

sub _filters_line {
    my $f = shift;
    return 'decade=' . ($f->{decade} || 'any')
         . '; genre=' . ($f->{genre} || 'any')
         . '; energy=' . (_energy_word($f->{energy}))
         . '; language=' . ($f->{language} || 'any');
}

sub _energy_word {
    my $e = shift // '';
    return '' if $e eq '';
    return 'chill'   if $e < 34;
    return 'balanced' if $e < 67;
    return 'intense';
}

sub _library_prompt {
    my ($f, $pool) = @_;
    my $lines = join("\n", map {
        $_->{id} . "\t" . $_->{artist} . "\t" . $_->{title} . "\t" . $_->{album} . "\t" . ($_->{year} || 0)
    } @$pool);
    return "Request: " . ($f->{prompt} || '(none — use the filters)')
         . "\nFilters: " . _filters_line($f)
         . "\nPick exactly " . $f->{count} . " tracks from the candidate list below, in play order."
         . "\nCandidates (id <TAB> artist <TAB> title <TAB> album <TAB> year):"
         . "\n" . $lines
         . "\nReply exactly:"
         . "\n{\"title\": \"short playlist title\", \"tracks\": [{\"id\": 0, \"reason\": \"<= 12 words\"}]}";
}

sub _free_prompt {
    my ($f) = @_;
    return "Request: " . ($f->{prompt} || '(none — use the filters)')
         . "\nFilters: " . _filters_line($f)
         . "\nSuggest exactly " . $f->{count} . " real tracks that fit. Use widely available recordings."
         . "\nReply exactly:"
         . "\n{\"title\": \"short playlist title\","
         . "\n \"tracks\": [{\"artist\": \"\", \"title\": \"\", \"album\": \"\", \"year\": 0, \"reason\": \"<= 12 words\"}]}";
}

# ---------------------------------------------------------------- provider

sub _call_provider {
    my ($job, $messages, $json_mode) = @_;

    my $body = encode_json({
        model       => $prefs->get('aiModel'),
        temperature => 0 + ($prefs->get('aiTemperature') // 0.7),
        messages    => $messages,
        ($json_mode && $prefs->get('aiJsonMode') ? (response_format => { type => 'json_object' }) : ()),
    });

    my $url = $prefs->get('aiBaseUrl') || '';
    $url =~ s{/+$}{};
    $url .= '/chat/completions';

    Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $res = shift;
            my $text = eval { decode_json($res->content)->{choices}[0]{message}{content} };
            if (!$text) {
                $job->{status} = 'error';
                $job->{error}  = 'provider returned no content';
                return;
            }
            _finish_job($job, $text);
        },
        sub {
            my $res = shift;
            my $code = eval { $res->code } || 0;
            # 400/422 usually means response_format is unsupported: retry once plain.
            if ($json_mode && ($code == 400 || $code == 422)) {
                $log->warn("studio: provider rejected json mode (HTTP $code), retrying without");
                _call_provider($job, $messages, 0);
                return;
            }
            $job->{status} = 'error';
            $job->{error}  = 'provider error (HTTP ' . ($code || 'n/a') . ')';
        },
        { timeout => _int($prefs->get('aiTimeout'), 120) },
    )->post($url,
        'Content-Type' => 'application/json',
        (($prefs->get('aiApiKey') || '') ne '' ? ('Authorization' => 'Bearer ' . $prefs->get('aiApiKey')) : ()),
        $body,
    );
}

# Tolerant JSON extraction: strip ```json fences, take the first balanced {..} block.
sub _extract_json {
    my $text = shift // '';
    $text =~ s/^\s*```(?:json)?\s*//i;
    $text =~ s/\s*```\s*$//;
    my $start = index($text, '{');
    return undef if $start < 0;
    my $depth = 0;
    my $in_str = 0;
    my $esc = 0;
    for (my $i = $start; $i < length($text); $i++) {
        my $ch = substr($text, $i, 1);
        if ($in_str) {
            if ($esc) { $esc = 0 }
            elsif ($ch eq '\\') { $esc = 1 }
            elsif ($ch eq '"') { $in_str = 0 }
            next;
        }
        if    ($ch eq '"') { $in_str = 1 }
        elsif ($ch eq '{') { $depth++ }
        elsif ($ch eq '}') {
            $depth--;
            if ($depth == 0) {
                my $block = substr($text, $start, $i - $start + 1);
                return eval { decode_json(Encode::encode_utf8($block)) };
            }
        }
    }
    return undef;
}

sub _finish_job {
    my ($job, $text) = @_;

    my $data = eval { _parse_and_resolve($job, $text) };
    if (!$data) {
        $job->{status} = 'error';
        $job->{error}  = $@ ? "processing failed: $@" : 'model returned no JSON';
        return;
    }
    $job->{status} = 'done';
    _maybe_resolve_online($job);
}

sub _parse_and_resolve {
    my ($job, $text) = @_;

    my $data = _extract_json($text);
    die "model returned no JSON\n" if !$data || ref $data ne 'HASH' || ref $data->{tracks} ne 'ARRAY';

    $job->{title} = substr($data->{title} || 'AI playlist', 0, 120);

    $job->{tracks} = $job->{mode} eq 'library'
        ? _resolve_library($job, $data->{tracks})
        : _resolve_free($job, $data->{tracks});

    return 1;
}

sub _row {
    my (%kv) = @_;
    return {
        id     => $kv{id}     // 0,
        title  => _d($kv{title}  // ''),
        artist => _d($kv{artist} // ''),
        album  => _d($kv{album}  // ''),
        year   => _int($kv{year}, 0),
        coverid => $kv{coverid} // '',
        url    => $kv{url}    // '',
        source => $kv{source} // '',
        match  => $kv{match}  // 'found',
        reason => _d(substr($kv{reason} // '', 0, 200)),
    };
}

sub _resolve_library {
    my ($job, $items) = @_;
    my @rows;
    foreach my $it (@$items) {
        last if @rows >= 100;
        next unless ref $it eq 'HASH';
        my $id = _int($it->{id}, -1);
        my $track = $id >= 0 ? Slim::Schema->find('Track', $id) : undef;
        if ($track) {
            push @rows, _row(
                id      => $track->id,
                title   => $track->title,
                artist  => (eval { $track->artist->name } || ''),
                album   => (eval { $track->album->title } || ''),
                year    => $track->year,
                coverid => $track->coverid,
                match   => 'found',
                reason  => $it->{reason} // '',
            );
        } else {
            push @rows, _row(title => '?', match => 'missing', reason => 'unknown id ' . $id);
        }
    }
    return \@rows;
}

sub _resolve_free {
    my ($job, $items) = @_;
    my @rows;
    foreach my $it (@$items) {
        last if @rows >= 100;
        next unless ref $it eq 'HASH';
        my ($row, $match) = _match_candidate($it);
        push @rows, _row(%$row, match => $match, reason => $it->{reason} // '');
    }
    return \@rows;
}

# ---------------------------------------------------------------- matching ladder

sub _norm {
    my $s = shift // '';
    $s = Encode::decode_utf8($s) unless Encode::is_utf8($s);
    $s = lc $s;
    $s =~ s/&/ and /g;
    $s =~ s/\b(feat|featuring|with|ft)\.?\s.*$//;
    $s =~ s/\s*[-–]\s*(remaster(ed)?|deluxe|expanded|bonus|single version|radio edit|mono|stereo).*$//;
    $s =~ s/\([^)]*\)//g;
    $s =~ s/[^\p{L}\p{N} ]+/ /g;
    $s =~ s/\s+/ /g;
    $s =~ s/^\s+|\s+$//g;
    return $s;
}

# Build an artist-keyed lookup of the library once per job run.
my %_lib_cache;

sub _lib_tracks {
    my $force = shift;
    if ($force || !%_lib_cache) {
        %_lib_cache = ();
        my $dbh = Slim::Schema->dbh;
        my $rows = $dbh->selectall_arrayref(q{
            SELECT t.id, t.title, t.titlesearch, t.year, t.coverid,
                   c.name AS artist, c.namesearch AS artistsearch,
                   a.title AS album, a.titlesearch AS albumsearch
              FROM tracks t
              LEFT JOIN contributors c ON c.id = t.primary_artist
              LEFT JOIN albums a       ON a.id = t.album
             WHERE t.audio = 1 AND t.content_type NOT IN ('cpl','src','ssp','dir')
        }, { Slice => {} });
        foreach my $r (@{ $rows || [] }) {
            next unless $r->{artistsearch};
            push @{ $_lib_cache{ $r->{artistsearch} } }, $r;
        }
    }
    return \%_lib_cache;
}

sub _match_candidate {
    my ($it) = @_;
    my $artist = _norm($it->{artist} // '');
    my $title  = _norm($it->{title}  // '');
    my $album  = _norm($it->{album}  // '');

    my $lib = _lib_tracks(0);
    my $uc  = uc $artist;
    my $cands = $lib->{$uc};

    if ($cands && @$cands) {
        # 1: exact artist + normalized title
        foreach my $t (@$cands) {
            if (_norm($t->{title}) eq $title && $title ne '') {
                return (_found_row($t), 'found');
            }
        }
        # 2: same artist + same normalized album
        if ($album ne '') {
            foreach my $t (@$cands) {
                if (_norm($t->{album}) eq $album) {
                    return (_found_row($t), 'uncertain');
                }
            }
        }
        # 3: same artist, first track
        return (_found_row($cands->[0]), 'uncertain');
    }

    # 4: artist name search fallback (handles case/accents differences)
    if ($artist ne '') {
        foreach my $key (keys %$lib) {
            next unless index($key, $uc) >= 0 || index($uc, $key) >= 0;
            my $list = $lib->{$key};
            foreach my $t (@$list) {
                if ($title ne '' && _norm($t->{title}) eq $title) {
                    return (_found_row($t), 'uncertain');
                }
            }
        }
    }

    return ({ title => $it->{title} // '', artist => $it->{artist} // '', album => $it->{album} // '', year => _int($it->{year}, 0) }, 'missing');
}

sub _found_row {
    my $t = shift;
    return {
        id      => $t->{id},
        title   => Encode::decode_utf8($t->{title}  // ''),
        artist  => Encode::decode_utf8($t->{artist} // ''),
        album   => Encode::decode_utf8($t->{album}  // ''),
        year    => $t->{year} || 0,
        coverid => $t->{coverid} // '',
    };
}

# ---------------------------------------------------------------- job commands

sub _result {
    my $request = shift;
    my $job = $JOBS{ _int($request->getParam('job'), 0) };
    if (!$job) {
        $request->addResult('status', 'error');
        $request->addResult('error', 'job not found (expired or cancelled)');
        $request->setStatusDone();
        return;
    }

    $request->addResult('status', $job->{status});
    $request->addResult('mode',   $job->{mode});
    $request->addResult('phase',  $job->{phase} || '');
    $request->addResult('title',  $job->{title} || '');
    $request->addResult('pool',   $job->{pool});
    $request->addResult('dropped', $job->{dropped} || 0);
    $request->addResult('resolved_online', $job->{resolved_online} || 0);
    $request->addResult('error',  $job->{error} || '');

    my $cnt = 0;
    my ($found, $missing) = (0, 0);
    foreach my $t (@{ $job->{tracks} || [] }) {
        $found++  if $t->{match} ne 'missing';
        $missing++ if $t->{match} eq 'missing';
        $request->addResultLoop('tracks_loop', $cnt, $_, $t->{$_}) for keys %$t;
        $cnt++;
    }
    $request->addResult('count',  $cnt);
    $request->addResult('found',  $found);
    $request->addResult('missing', $missing);
    $request->setStatusDone();
}

sub _replace {
    my $request = shift;
    my $job = $JOBS{ _int($request->getParam('job'), 0) };
    my $idx = _int($request->getParam('index'), -1);
    if (!$job || $job->{status} ne 'done' || $idx < 0 || $idx > $#{ $job->{tracks} }) {
        $request->setStatusBadParams();
        return;
    }

    my $row = $job->{tracks}[$idx];
    my ($new, $ok) = _same_artist_fallback($row);
    if ($ok) {
        $job->{tracks}[$idx] = { %$new, match => 'uncertain', reason => 'replacement' };
    }
    $request->addResult('ok', $ok ? 1 : 0);
    if ($ok) {
        $request->addResultLoop('track', 0, $_, $new->{$_}) for keys %$new;
        $request->addResultLoop('track', 0, 'match', 'uncertain');
    }
    $request->setStatusDone();
}

sub _same_artist_fallback {
    my $row = shift;
    my $artist = _norm($row->{artist} // '');
    return ({}, 0) if $artist eq '';
    my $lib = _lib_tracks(0);
    my $cands = $lib->{ uc $artist } or return ({}, 0);
    foreach my $t (@$cands) {
        next if $t->{id} == ($row->{id} || 0);
        return (_found_row($t), 1);
    }
    return ({}, 0);
}

sub _play {
    my $request = shift;
    my $job = $JOBS{ _int($request->getParam('job'), 0) };
    my $mode = $request->getParam('mode') // 'load';
    $mode = 'load' unless $mode =~ /^(load|add)$/;
    if (!$job || $job->{status} ne 'done') {
        $request->setStatusBadParams();
        return;
    }
    my $client = Slim::Player::Client::getClient($request->getParam('player'));
    if (!$client) {
        $request->addResult('error', 'no such player');
        $request->setStatusDone();
        return;
    }
    my @rows = grep { $_->{match} ne 'missing' && ($_->{id} || $_->{url}) } @{ $job->{tracks} };
    if (!@rows) {
        $request->addResult('error', 'nothing playable (all matches missing)');
        $request->setStatusDone();
        return;
    }
    # Sequential per-row adds keep the playlist order identical to the result
    # list when local (track id) and online (url) rows are interleaved.
    $client->execute([ 'playlist', 'clear' ]) if $mode eq 'load';
    my $queued = 0;
    foreach my $r (@rows) {
        my $url = $r->{url};
        if (!$url && $r->{id}) {
            my $track = Slim::Schema->find('Track', $r->{id});
            $url = $track ? $track->url : undef;
        }
        next unless $url;
        $client->execute([ 'playlist', 'add', $url ]);
        $queued++;
    }
    $client->execute([ 'play' ]) if $mode eq 'load';
    $request->addResult('queued', $queued);
    $request->setStatusDone();
}

sub _save {
    my $request = shift;
    my $job = $JOBS{ _int($request->getParam('job'), 0) };
    my $name = substr($request->getParam('name') || ($job ? $job->{title} : '') || 'AI playlist', 0, 120);
    $name =~ s/^\s+|\s+$//g;
    if (!$job || $job->{status} ne 'done' || $name eq '') {
        $request->setStatusBadParams();
        return;
    }

    my @tracks = grep { $_->{match} ne 'missing' && ($_->{id} || $_->{url}) } @{ $job->{tracks} };
    if (!@tracks) {
        $request->addResult('error', 'nothing to save (all matches missing)');
        $request->setStatusDone();
        return;
    }

    my $created = Slim::Control::Request::executeRequest(undef, [ 'playlists', 'new', 'name:' . $name ]);
    my $playlistId = 0;
    if (blessed($created) && $created->getResult('playlist_id')) {
        $playlistId = $created->getResult('playlist_id');
    } else {
        my $existing = Slim::Schema->single('Playlist', { title => $name });
        $playlistId = $existing->id if blessed($existing);
    }

    if (!$playlistId) {
        $request->addResult('error', 'failed to create playlist');
        $request->setStatusDone();
        return;
    }

    my $added = 0;
    foreach my $t (@tracks[ 0 .. ($#tracks < 499 ? $#tracks : 499) ]) {
        my $url = $t->{url};
        if (!$url && $t->{id}) {
            my $track = Slim::Schema->find('Track', $t->{id});
            next unless $track;
            $url = $track->url;
        }
        Slim::Control::Request::executeRequest(undef, [
            'playlists', 'edit', 'playlist_id:' . $playlistId, 'cmd:add', 'url:' . $url,
        ]);
        $added++;
    }

    $request->addResult('playlist_id', $playlistId);
    $request->addResult('added', $added);
    $request->setStatusDone();
}

sub _cancel {
    my $request = shift;
    delete $JOBS{ _int($request->getParam('job'), 0) };
    $request->setStatusDone();
}

# ---------------------------------------------------------------- charts
#
# Studio's "Charts" tab: playlist suggestions from Last.fm / ListenBrainz,
# matched against the library with the same ladder as AI free mode. The
# result is registered as a pre-completed job so ai-play/ai-save/ai-replace/
# ai-result are source-agnostic.

my $CHART_CACHE_AGE = 7 * 24 * 60 * 60;

sub _charts_generate {
    my $request = shift;

    my %p = (
        source => $request->getParam('source') || 'lastfm-tag',
        period => $request->getParam('period') || '1month',
        range  => $request->getParam('range')  || 'month',
        tag    => $request->getParam('tag')    || '',
        artist => $request->getParam('artist') || '',
        count  => _clamp($request->getParam('count'), 5, 50, 20),
    );

    my %spec = (
        'lastfm-top'     => { title => 'Last.fm top (' . $p{period} . ')',   need => '' },
        'lastfm-loved'   => { title => 'Last.fm loved tracks',               need => '' },
        'lastfm-tag'     => { title => "Last.fm tag: $p{tag}",               need => 'tag' },
        'lastfm-similar' => { title => "Similar to $p{artist}",              need => 'artist' },
        'lb-top'         => { title => 'ListenBrainz top (' . $p{range} . ')', need => '' },
    );
    my $spec = $spec{ $p{source} };
    if (!$spec) {
        $request->setStatusBadParams();
        return;
    }
    if ($spec->{need} eq 'tag' && $p{tag} eq '') {
        $request->addResult('error', 'Pick a tag or type one');
        $request->setStatusDone();
        return;
    }
    if ($spec->{need} eq 'artist' && $p{artist} eq '') {
        $request->addResult('error', 'Type an artist name');
        $request->setStatusDone();
        return;
    }

    my $user;
    if ($p{source} =~ /^lastfm/ || $p{source} eq 'lastfm-loved') {
        $user = Plugins::LMSkin::Plugin::lastfmUser();
        if ($user eq '' && $p{source} =~ /^(lastfm-top|lastfm-loved)$/) {
            $request->addResult('error', 'No Last.fm username — link an account in the AudioScrobbler plugin settings');
            $request->setStatusDone();
            return;
        }
    }

    my ($url, $key);
    my $chain;
    if ($p{source} eq 'lastfm-top') {
        $key = "top-$user-$p{period}";
        $url = _lf_url('user.getTopTracks', user => $user, period => $p{period}, limit => 100);
    } elsif ($p{source} eq 'lastfm-loved') {
        $key = "loved-$user";
        $url = _lf_url('user.getLovedTracks', user => $user, limit => 100);
    } elsif ($p{source} eq 'lastfm-tag') {
        $key = "tag-" . lc($p{tag});
        $url = _lf_url('tag.getTopTracks', tag => $p{tag}, limit => 100);
    } elsif ($p{source} eq 'lastfm-similar') {
        $key = "similar-" . lc($p{artist});
        # two-step: artist's top track -> similar tracks (true "similar" radio)
        $url = _lf_url('artist.getTopTracks', artist => $p{artist}, limit => 1);
        $chain = 'similar';
    } else {    # lb-top
        $user = $prefs->get('lbUser') || $lbUserResolvedCharts || '';
        if ($user eq '') {
            $request->addResult('error', 'No ListenBrainz username — set it in LMSkin settings');
            $request->setStatusDone();
            return;
        }
        $key = "lb-top-$user-$p{range}";
        $url = 'https://api.listenbrainz.org/1/stats/user/' . uri_escape_utf8($user)
             . '/recordings?range=' . uri_escape_utf8($p{range}) . '&count=50';
    }

    my $cached = _chart_cache_read($key);
    if (defined $cached) {
        _charts_finish($request, \%p, $spec, $cached);
        return;
    }

    $request->setStatusProcessing();
    _charts_fetch($request, $key, $url, \%p, $spec, $chain);
}

sub _lf_url {
    my ($method, %params) = @_;
    my $key = Plugins::LMSkin::Plugin::lastfmApiKey();
    my $url = 'https://ws.audioscrobbler.com/2.0/?format=json&api_key=' . $key . '&method=' . $method;
    $url .= '&' . $_ . '=' . uri_escape_utf8($params{$_}) for keys %params;
    return $url;
}

sub _charts_fetch {
    my ($request, $key, $url, $p, $spec, $chain) = @_;

    my @headers;
    if ($url =~ /listenbrainz/ && ($prefs->get('lbToken') || '') ne '') {
        push @headers, 'Authorization' => 'Token ' . $prefs->get('lbToken');
    }

    Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $res = shift;
            my $content = $res->content;

            if ($chain && $chain eq 'similar') {
                # step 1 done: find the artist's top track, then fetch similar
                my $bytes = Encode::is_utf8($content) ? Encode::encode_utf8($content) : $content;
                my $data = eval { decode_json($bytes) };
                my $tracks = _lf_track_list($data);
                my $seed = $tracks->[0];
                if (!$seed) {
                    $request->addResult('error', "No tracks found for artist '$p->{artist}'");
                    $request->setStatusDone();
                    return;
                }
                my $seed_artist = ref $seed->{artist} eq 'HASH' ? $seed->{artist}{name} : $seed->{artist};
                my $url2 = _lf_url('track.getSimilar',
                    artist => $seed_artist, track => $seed->{name}, limit => 100);
                $chain = undef;
                _charts_fetch($request, $key, $url2, $p, $spec, undef);
                return;
            }

            _chart_cache_write($key, $content);
            _charts_finish($request, $p, $spec, $content);
        },
        sub {
            my $res = shift;
            my $code = eval { $res->code } || 0;
            $request->addResult('error', "charts request failed (HTTP $code)");
            $request->setStatusDone();
        },
        { timeout => 25 },
    )->get($url, @headers);
}

# Tolerant extraction of a track list from various Last.fm response shapes.
sub _lf_track_list {
    my $data = shift;
    return [] unless ref $data eq 'HASH';
    for my $k (qw(toptracks lovedtracks similartracks tracks)) {
        my $node = $data->{$k};
        next unless ref $node eq 'HASH' && ref $node->{track} eq 'ARRAY';
        return $node->{track};
    }
    return [];
}

sub _charts_finish {
    my ($request, $p, $spec, $content) = @_;

    my $bytes = Encode::is_utf8($content) ? Encode::encode_utf8($content) : $content;
    my $data = eval { decode_json($bytes) };
    my @cands;
    if ($p->{source} eq 'lb-top') {
        my $recs = (ref $data eq 'HASH' && ref $data->{payload} eq 'HASH') ? $data->{payload}{recordings} : undef;
        if (ref $recs eq 'ARRAY') {
            push @cands, { artist => $_->{artist_name}, title => $_->{track_name}, album => $_->{release_name} // '' } for @$recs;
        }
    } else {
        my $tracks = _lf_track_list($data);
        foreach my $t (@$tracks) {
            next unless ref $t eq 'HASH';
            my $artist = ref $t->{artist} eq 'HASH' ? $t->{artist}{name} : $t->{artist};
            push @cands, { artist => $artist // '', title => $t->{name} // '', album => '' };
        }
    }

    if (!@cands) {
        $request->addResult('error', 'the service returned no tracks');
        $request->setStatusDone();
        return;
    }

    my $lib = _lib_tracks(0);
    my (@rows, %seen);
    my ($found, $missing) = (0, 0);
    foreach my $c (@cands) {
        last if @rows >= $p->{count};
        my ($row, $match) = _match_candidate($c);
        next if $row->{id} && $seen{ $row->{id} }++;
        $found++  if $match ne 'missing';
        $missing++ if $match eq 'missing';
        push @rows, _row(%$row, match => $match, reason => '');
    }

    my $job = {
        id      => ++$JOB_SEQ,
        status  => 'done',
        mode    => 'library',
        pool    => scalar @cands,
        dropped => 0,
        title   => $spec->{title},
        tracks  => \@rows,
        error   => '',
        created => time(),
    };
    $JOBS{ $job->{id} } = $job;

    $request->addResult('job',     $job->{id});
    $request->addResult('status',  'done');
    $request->addResult('found',   $found);
    $request->addResult('missing', $missing);
    $request->setStatusDone();

    _maybe_resolve_online($job);
}

sub _chart_cache_read {
    my $key = shift;
    my $path = _chart_cache_path($key);
    return undef unless -e $path && time() - (stat($path))[9] < $CHART_CACHE_AGE;
    my $content = Plugins::LMSkin::Plugin::_readFile($path);
    return defined $content ? $content : undef;
}

sub _chart_cache_write {
    my ($key, $content) = @_;
    my $path = _chart_cache_path($key);
    my $dir  = Plugins::LMSkin::Plugin::_cacheDir('charts');
    if (open(my $fh, '>:encoding(UTF-8)', $path)) {
        print $fh $content;
        close($fh);
    }
}

sub _chart_cache_path {
    my $key = shift;
    $key =~ s{[/\\:?&= ]}{-}g;
    return File::Spec->catfile(Plugins::LMSkin::Plugin::_cacheDir('charts'), $key . '.json');
}

# ---------------------------------------------------------------- online resolution
#
# Rows the library ladder left "missing" get one more chance on the activated
# streaming services, in the user's fixed priority order: Qobuz -> TIDAL ->
# Spotify. A row is only offered on a lower-priority service when every
# higher-priority service failed to match it. Hits become playable rows with
# url + source, so ai-play/ai-save treat them like local tracks.
#
# The phase runs entirely async: the job flips back to status 'running' with
# phase 'online' while searches are in flight (bounded concurrency), and a
# watchdog forces 'done' after 60 s no matter what.

my @ONLINE_SERVICES = (
    { id => 'qobuz',  pref => 'aiOnlineQobuz',  search => \&_os_search_qobuz  },
    { id => 'tidal',  pref => 'aiOnlineTidal',  search => \&_os_search_tidal  },
    { id => 'spotty', pref => 'aiOnlineSpotty', search => \&_os_search_spotty },
);

my $OS_CONCURRENCY = 3;
my $OS_WATCHDOG    = 60;

my %_os_available;

sub _maybe_resolve_online {
    my ($job) = @_;

    my @missing = grep { $job->{tracks}[$_]{match} eq 'missing' } 0 .. $#{ $job->{tracks} };
    return unless @missing;
    return unless _int($prefs->get('aiOnlineResolve'), 1);

    my $limit = _int($prefs->get('aiOnlineLimit'), 30);
    $limit = 5   if $limit < 5;
    $limit = 100 if $limit > 100;
    splice(@missing, $limit) if @missing > $limit;

    my $timer = bless { job => $job->{id} }, 'Plugins::LMSkin::Ai::OsTimer';
    $job->{_os} = { queue => \@missing, active => 0, cache => {}, timer => $timer };
    $job->{status}          = 'running';
    $job->{phase}           = 'online';
    $job->{resolved_online} = 0;

    Slim::Utils::Timers::setTimer($timer, time() + $OS_WATCHDOG, \&_os_watchdog);
    _os_pump($job);
}

sub _os_watchdog {
    my $timer = shift;
    my $job = $JOBS{ $timer->{job} } or return;
    $job->{_os} or return;
    _os_finish($job);
}

sub _os_finish {
    my ($job) = @_;
    if ($job->{_os}) {
        Slim::Utils::Timers::killTimers($job->{_os}{timer});
        delete $job->{_os};
    }
    $job->{status} = 'done';
    delete $job->{phase};
}

sub _os_pump {
    my ($job) = @_;
    my $os = $job->{_os} or return;

    while ($os->{active} < $OS_CONCURRENCY && @{ $os->{queue} }) {
        my $idx = shift @{ $os->{queue} };
        _os_step($job, $idx, 0);
        return if !$job->{_os};    # watchdog fired mid-pump
    }

    if (!@{ $os->{queue} } && !$os->{active}) {
        _os_finish($job);
    }
}

# Try services from $svcIdx onward for this row; either applies a hit, recurses
# into the next service (cached results), or starts an async search.
sub _os_step {
    my ($job, $idx, $svcIdx) = @_;
    my $os = $job->{_os} or return;
    my $row = $job->{tracks}[$idx];

    my $query = _norm($row->{artist} . ' ' . $row->{title});
    $query =~ s/^\s+|\s+$//g;

    for (my $i = $svcIdx; $i < @ONLINE_SERVICES; $i++) {
        my $svc = $ONLINE_SERVICES[$i];
        next unless _int($prefs->get($svc->{pref}), 1);
        next unless _os_available($svc->{id});
        next if $query eq '';

        if (exists $os->{cache}{ $svc->{id} }{ $query }) {
            my $hit = _os_pick($row, $os->{cache}{ $svc->{id} }{ $query });
            if ($hit) { _os_apply($job, $idx, $svc, $hit); return; }
            next;    # cached miss: fall through to the next service
        }

        $os->{active}++;
        my $fired = 0;
        $svc->{search}->($query, 10, sub {
            return if $fired++;    # a buggy plugin double-callback must not corrupt state
            my $results = shift || [];
            $os->{cache}{ $svc->{id} }{ $query } = $results;
            $os->{active}--;
            return if !$job->{_os};    # job finished (watchdog) meanwhile
            if (my $hit = _os_pick($row, $results)) {
                _os_apply($job, $idx, $svc, $hit);
            } else {
                _os_step($job, $idx, $i + 1);
            }
            _os_pump($job);
        });
        return;    # async search in flight
    }

    # no service matched (or none enabled): row stays missing
    _os_pump($job);
}

sub _os_pick {
    my ($row, $results) = @_;
    my $artist = _norm($row->{artist});
    my $title  = _norm($row->{title});
    my $album  = _norm($row->{album});
    return undef if $artist eq '' || $title eq '';

    foreach my $r (@$results) {    # 1: exact artist + title
        return $r if _norm($r->{artist}) eq $artist && _norm($r->{title}) eq $title;
    }
    if ($album ne '') {            # 2: exact artist + album
        foreach my $r (@$results) {
            return $r if _norm($r->{artist}) eq $artist && _norm($r->{album}) eq $album;
        }
    }
    foreach my $r (@$results) {    # 3: same artist, first result
        return $r if _norm($r->{artist}) eq $artist;
    }
    return undef;
}

sub _os_apply {
    my ($job, $idx, $svc, $hit) = @_;
    my $row = $job->{tracks}[$idx];
    $row->{id}      = 0;
    $row->{url}     = $hit->{url};
    $row->{source}  = $svc->{id};
    $row->{match}   = 'online';
    $row->{title}   = $hit->{title}  || $row->{title};
    $row->{artist}  = $hit->{artist} || $row->{artist};
    $row->{album}   = $hit->{album}  || $row->{album};
    $row->{year}    = $hit->{year}   || $row->{year};
    $row->{coverid} = $hit->{cover}  || '';
    $job->{resolved_online}++;
}

sub _os_available {
    my $id = shift;
    return $_os_available{$id} if defined $_os_available{$id};
    my $ok;
    if ($id eq 'qobuz') {
        $ok = eval { require Plugins::Qobuz::API; require Plugins::Qobuz::API::Common; Plugins::Qobuz::API::Common->getSomeUserId() ? 1 : 0 } ? 1 : 0;
    } elsif ($id eq 'tidal') {
        $ok = eval { require Plugins::TIDAL::Plugin; require Plugins::TIDAL::API; 1 } ? 1 : 0;
    } elsif ($id eq 'spotty') {
        $ok = eval { require Plugins::Spotty::Plugin; require Plugins::Spotty::API; 1 } ? 1 : 0;
    } else {
        $ok = 0;
    }
    return $_os_available{$id} = $ok;
}

# Any connected player will do: TIDAL/Spotty resolve the account from client
# prefs. No player online -> those services just report no results.
my $_os_client;
sub _os_client {
    return $_os_client if $_os_client && $_os_client->connected;
    $_os_client = undef;
    foreach my $client (Slim::Player::Client::clients()) {
        if ($client && $client->connected) {
            $_os_client = $client;
            last;
        }
    }
    return $_os_client;
}

sub _os_search_qobuz {
    my ($query, $limit, $cb) = @_;
    my $api = eval { Plugins::Qobuz::Plugin::getAPIHandler(undef) };
    if (!$api) { $cb->([]); return; }
    $api->search(sub {
        my $res = shift || {};
        my $items = (ref $res eq 'HASH' && ref $res->{tracks} eq 'HASH' && ref $res->{tracks}{items} eq 'ARRAY')
            ? $res->{tracks}{items} : [];
        my @out;
        foreach my $t (@$items) {
            next unless ref $t eq 'HASH' && $t->{id} && $t->{streamable};
            my $artist = (ref $t->{performer} eq 'HASH' ? $t->{performer}{name} : '') || '';
            if ($artist eq '' && ref $t->{album} eq 'HASH') {
                my @a = map { $_->{name} } Plugins::Qobuz::API::Common->getMainArtists($t->{album});
                $artist = join(', ', @a);
            }
            push @out, {
                title  => $t->{title} // '',
                artist => $artist,
                album  => (ref $t->{album} eq 'HASH' ? $t->{album}{title} : '') // '',
                year   => (ref $t->{album} eq 'HASH' ? ($t->{album}{year} || 0) : 0),
                url    => Plugins::Qobuz::API::Common->getUrl(undef, $t),
                cover  => (ref $t->{album} eq 'HASH' ? (Plugins::Qobuz::API::Common->getImageFromImagesHash($t->{album}{image}) || '') : ''),
            };
        }
        $cb->(\@out);
    }, $query, 'tracks', { limit => $limit });
}

sub _os_search_tidal {
    my ($query, $limit, $cb) = @_;
    my $client = _os_client();
    my $api = $client ? eval { Plugins::TIDAL::Plugin::getAPIHandler($client) } : undef;
    if (!$api) { $cb->([]); return; }
    my $ct = eval { Plugins::TIDAL::API::getFormat() } || 'flac';
    $api->search(sub {
        my $items = shift || [];
        my @out;
        foreach my $t (@$items) {
            next unless ref $t eq 'HASH' && $t->{id};
            my $artist = ref $t->{artist} eq 'HASH' ? $t->{artist}{name} : ($t->{artist} // '');
            push @out, {
                title  => $t->{title} // '',
                artist => $artist,
                album  => $t->{album} // '',
                year   => $t->{year} || 0,
                url    => 'tidal://' . $t->{id} . '.' . $ct,
                cover  => $t->{cover} // $t->{icon} // '',
            };
        }
        $cb->(\@out);
    }, { type => 'tracks', search => $query, limit => $limit });
}

sub _os_search_spotty {
    my ($query, $limit, $cb) = @_;
    my $client = _os_client();
    my $api = $client ? eval { Plugins::Spotty::Plugin::getAPIHandler($client) } : undef;
    if (!$api) { $cb->([]); return; }
    $api->search(sub {
        my $items = shift || [];
        my @out;
        foreach my $t (@$items) {
            next unless ref $t eq 'HASH' && $t->{uri};
            my $artist = join(', ', map { $_->{name} } @{ $t->{artists} || [] });
            push @out, {
                title  => $t->{name} // '',
                artist => $artist,
                album  => (ref $t->{album} eq 'HASH' ? $t->{album}{name} : '') // '',
                year   => substr($t->{release_date} // '', 0, 4) || 0,
                url    => 'spotify://' . $t->{uri},
                cover  => $t->{image} // '',
            };
        }
        $cb->(\@out);
    }, { query => $query, type => 'track', limit => $limit });
}

# ---------------------------------------------------------------- pool

# Returns { rows, total, dropped }. rows is the (possibly stratified) sample
# the job works with; total/dropped feed the UI's honest reporting.
sub _build_pool {
    my $f = shift;

    my ($where, @bind) = Plugins::LMSkin::Plugin::_focusFilterSql({
        genre  => $f->{genre},
        decade => $f->{decade},
    });

    my $dbh = Slim::Schema->dbh;
    my $rows = $dbh->selectall_arrayref(
        "SELECT t.id, t.title, t.year, t.coverid, c.name AS artist, a.title AS album"
        . " FROM tracks t"
        . " LEFT JOIN contributors c ON c.id = t.primary_artist"
        . " LEFT JOIN albums a       ON a.id = t.album"
        . " WHERE t.audio = 1 AND t.content_type NOT IN ('cpl','src','ssp','dir') $where"
        . " ORDER BY c.name, a.title, t.tracknum",
        { Slice => {} },
        @bind,
    ) || [];

    foreach my $r (@$rows) {
        $r->{artist} = Encode::decode_utf8($r->{artist} // '');
        $r->{title}  = Encode::decode_utf8($r->{title}  // '');
        $r->{album}  = Encode::decode_utf8($r->{album}  // '');
        $r->{coverid} //= '';
    }

    my $total = scalar @$rows;
    my $cap   = _int($prefs->get('aiMaxCandidates'), 800);

    if ($total > $cap * 3) {
        # Stratified sample: round-robin one track per artist until the cap.
        my %by_artist;
        push @{ $by_artist{ $_->{artist} || '?' } }, $_ for @$rows;
        my @sample;
        my $rounds = 0;
        while (@sample < $cap && $rounds < 500) {
            my $remaining = 0;
            foreach my $a (sort keys %by_artist) {
                if (@{ $by_artist{$a} }) {
                    push @sample, shift @{ $by_artist{$a} };
                    $remaining++ if @{ $by_artist{$a} };
                    last if @sample >= $cap;
                }
            }
            $rounds++;
            last if !$remaining;
        }
        return { rows => \@sample, total => $total, dropped => $total - scalar(@sample) };
    }

    return { rows => $rows, total => $total, dropped => 0 };
}

# ---------------------------------------------------------------- helpers

sub _int {
    my ($v, $d) = @_;
    return (defined $v && $v =~ /^-?\d+$/) ? int($v) : $d;
}

sub _clamp {
    my ($v, $min, $max, $d) = @_;
    my $n = _int($v, $d);
    $n = $min if $n < $min;
    $n = $max if $n > $max;
    return $n;
}

sub _d {
    my $v = shift // '';
    return Encode::decode_utf8($v) if !Encode::is_utf8($v);
    return $v;
}

1;

__END__
