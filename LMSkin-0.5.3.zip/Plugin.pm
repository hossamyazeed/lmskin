package Plugins::LMSkin::Plugin;

# LMSkin - a Roon-style skin for Lyrion Music Server.
#
# The command layer is a trimmed fork of lms-material 6.4.14
# (Copyright (c) 2018-2026 Craig Drummond, MIT license).
#
# Why a plugin at all: LMS only reads skins for their HTML assets. Anything that
# needs data LMS does not already expose (bootstrap config, facet counts, queue
# sorting) has to be a Slim::Control::Request handler, which means Perl.

use strict;

use Config;
use Encode;
use File::Spec;
use File::Path qw(make_path);
use JSON::XS qw(decode_json encode_json);
use List::Util qw(shuffle);
use Scalar::Util qw(blessed);
use Time::HiRes;
use URI::Escape qw(uri_unescape uri_escape_utf8);

use Slim::Control::Request;
use Slim::Menu::BrowseLibrary;
use Slim::Networking::SimpleAsyncHTTP;
use Slim::Music::Import;
use Slim::Music::VirtualLibraries;
use Slim::Player::Client;
use Slim::Player::Playlist;
use Slim::Player::Source;
use Slim::Plugin::Base;
use Slim::Schema;
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Network;
use Slim::Utils::OSDetect;
use Slim::Utils::PluginManager;
use Slim::Utils::Prefs;
use Slim::Utils::Strings qw(string);
use Slim::Utils::Timers;

my $log = Slim::Utils::Log->addLogCategory({
    'category'     => 'plugin.lmskin',
    'defaultLevel' => 'ERROR',
    'description'  => 'PLUGIN_LMSKIN'
});

my $prefs       = preferences('plugin.lmskin');
my $serverprefs = preferences('server');

my $pluginVersion = '0.1.0';
my $lmsVersion    = 0;

my $LASTFM_API_KEY = '5a854b839b10f8d46e630e8287c2299b';
my $MAX_CACHE_AGE  = 90 * 24 * 60 * 60;

# Timer object for the browse warm pass; declared here so shutdownPlugin can
# cancel it under strict.
my $WARM_OBJ = 'lmskin-warm';

# Plugins whose presence changes the UI. The client reads these flags from
# bootstrap and enables the matching features; nothing is hard-coded there.
my %PARTNER_PLUGINS = (
    mai        => 'Plugins::MusicArtistInfo::Plugin',
    youtube    => 'Plugins::YouTube::Plugin',
    dstm       => 'Slim::Plugin::DontStopTheMusic::Plugin',
    customskip => 'Plugins::CustomSkip3::Plugin',
    lastmix    => 'Plugins::LastMix::Plugin',
    blissmix   => 'Plugins::BlissMixer::Plugin',
    randommix  => 'Slim::Plugin::RandomPlay::Plugin',
    users      => 'Plugins::Users::Plugin',
    qobuz      => 'Plugins::Qobuz::Plugin',
    tidal      => 'Plugins::TIDAL::Plugin',
    spotty     => 'Plugins::Spotty::Plugin',
);

sub initPlugin {
    my $class = shift;

    foreach my $part (split /\./, $::VERSION || '0') {
        $lmsVersion = ($lmsVersion * 100) + int($part);
    }

    my $data = eval { Slim::Utils::PluginManager->dataForPlugin($class) };
    $pluginVersion = $data->{version} if $data && $data->{version};

    $prefs->init({
        gridSize         => 180,
        pageSize         => 250,
        setPlayerLibrary => 0,
        accent           => 'a0b0ff',
        blur             => 24,
        aiEnabled        => 1,
        aiBaseUrl        => 'http://localhost:11434/v1',
        aiApiKey         => '',
        aiModel          => '',
        aiTemperature    => 0.7,
        aiMaxCandidates  => 800,
        aiTimeout        => 120,
        aiJsonMode       => 1,
        aiOnlineResolve  => 1,
        aiOnlineQobuz    => 1,
        aiOnlineTidal    => 1,
        aiOnlineSpotty   => 1,
        aiOnlineLimit    => 30,
        onlineFavorites  => 1,
        onlineFavs       => {},
        lastfmApiKey     => '',
        lbEnabled        => 0,
        lbToken          => '',
        lbUser           => '',
    });

    if (_isWebUI()) {
        require Plugins::LMSkin::Settings;
        Plugins::LMSkin::Settings->new();

        # Pre-cache art at the sizes the grid and the list actually use.
        Slim::Control::Request::executeRequest(undef, [ 'artworkspec', 'add', '300x300_f', 'LMSkin (Grid)' ]);
        Slim::Control::Request::executeRequest(undef, [ 'artworkspec', 'add', '150x150_f', 'LMSkin (List)' ]);
        Slim::Control::Request::executeRequest(undef, [ 'artworkspec', 'add', '600x600_f', 'LMSkin (Grid, HiDPI)' ]);
    }

    $class->initCLI();

    # Wrapped listening log (plays.db). Started before anything else so it
    # collects data from minute one; see lib/Plugins/LMSkin/PlayLog.pm.
    eval { require Plugins::LMSkin::PlayLog; Plugins::LMSkin::PlayLog::init(); 1 }
        or $log->error("PlayLog failed to start: $@");

    # Restore a player's virtual library if its queue is cleared.
    Slim::Control::Request::subscribe(\&_playQueueCleared, [ [ 'playlist' ], [ 'clear' ] ]);

    # PlayLog hooks.
    Slim::Control::Request::subscribe(\&Plugins::LMSkin::PlayLog::on_new_song, [ [ 'playlist' ], [ 'newsong' ] ]);
    Slim::Control::Request::subscribe(\&Plugins::LMSkin::PlayLog::on_pause,    [ [ 'playlist' ], [ 'pause' ] ]);
    Slim::Control::Request::subscribe(\&Plugins::LMSkin::PlayLog::on_stop,     [ [ 'playlist' ], [ 'stop' ] ]);

    # Warm the browse queries the UI issues first (see "browse warm" below).
    Slim::Control::Request::subscribe(\&_onRescanDone, [ [ 'rescan' ], [ 'done' ] ]);
    _scheduleWarm(20);
}

sub shutdownPlugin {
    Slim::Control::Request::unsubscribe(\&_playQueueCleared);
    Slim::Control::Request::unsubscribe(\&_onRescanDone);
    Slim::Utils::Timers::forgetTimer($WARM_OBJ);
    eval { Plugins::LMSkin::PlayLog::shutdown() };
}

sub getPluginVersion { return $pluginVersion }
sub getLmsVersion    { return $lmsVersion }

sub initCLI {
    #                                      |requires Client
    #                                      |  |is a Query
    #                                      |  |  |has Tags
    #                                      |  |  |  |Function to call
    #                                      C  Q  T  F
    Slim::Control::Request::addDispatch([ 'lmskin', '_cmd' ],        [ 0, 0, 1, \&_cliCommand ]);
    Slim::Control::Request::addDispatch([ 'lmskin-client', '_cmd' ], [ 1, 0, 1, \&_cliClientCommand ]);

    # UI notification topic. Other plugins can push a toast with:
    #   Slim::Control::Request::notifyFromArray(undef, ['lmskin','notification','info',$msg])
    Slim::Control::Request::addDispatch([ 'lmskin', 'notification', '_type', '_msg' ], [ 0, 0, 0, undef ]);
}

sub _pluginEnabled {
    my ($mod) = @_;
    return Slim::Utils::PluginManager->isEnabled($mod) ? 1 : 0;
}

# LMS exposes the web-UI flag as a sub on some start-up paths and as a
# package variable on others; accept either so this compiles under strict.
sub _isWebUI {
    return defined &main::WEBUI ? (main::WEBUI() ? 1 : 0) : ($main::WEBUI ? 1 : 0);
}

sub _windowTitle {
    my $t = $serverprefs->get('servername');
    return ($t && $t ne '') ? $t : 'Lyrion Music Server';
}

sub _intPref {
    my ($v, $d) = @_;
    return (defined $v && $v =~ /^-?\d+$/) ? int($v) : $d;
}

sub _stringPref {
    my ($v, $d) = @_;
    return (defined $v && $v ne '') ? $v : $d;
}

# Charts (Studio) + scrobbling helpers --------------------------------------

sub lastfmApiKey {
    my $k = $prefs->get('lastfmApiKey');
    return (defined $k && $k ne '') ? $k : $LASTFM_API_KEY;
}

# Last.fm username: LMSkin has none of its own, so borrow the account that
# AudioScrobbler has linked (namespace default, else any player's selection).
sub lastfmUser {
    my $u = eval { preferences('plugin.audioscrobbler')->get('account') } || '';
    if (!$u) {
        for my $client (Slim::Player::Client::clients()) {
            $u = eval { preferences('plugin.audioscrobbler')->client($client)->get('account') } || '';
            last if $u;
        }
    }
    return $u;
}

sub _cacheDir {
    my $name = shift;
    my $root = $serverprefs->get('cachedir') || Slim::Utils::Prefs::dir();
    my $dir  = File::Spec->catdir($root, 'lmskin', $name);
    make_path($dir) unless -d $dir;
    return $dir;
}

# Masked shape of the feature prefs: values plus configured-flags, never the
# key/token themselves. The client renders set/replace/clear from the flags.
sub _featurePrefs {
    return {
        aiEnabled       => _intPref($prefs->get('aiEnabled'), 1),
        aiBaseUrl       => _stringPref($prefs->get('aiBaseUrl'), 'http://localhost:11434/v1'),
        aiModel         => _stringPref($prefs->get('aiModel'), ''),
        aiTemperature   => 0 + ($prefs->get('aiTemperature') // 0.7),
        aiMaxCandidates => _intPref($prefs->get('aiMaxCandidates'), 800),
        aiTimeout       => _intPref($prefs->get('aiTimeout'), 120),
        aiOnlineResolve => _intPref($prefs->get('aiOnlineResolve'), 1),
        aiOnlineQobuz   => _intPref($prefs->get('aiOnlineQobuz'), 1),
        aiOnlineTidal   => _intPref($prefs->get('aiOnlineTidal'), 1),
        aiOnlineSpotty  => _intPref($prefs->get('aiOnlineSpotty'), 1),
        aiOnlineLimit   => _intPref($prefs->get('aiOnlineLimit'), 30),
        onlineFavorites => _intPref($prefs->get('onlineFavorites'), 1),
        aiKeySet        => ($prefs->get('aiApiKey') || '') ne '' ? 1 : 0,
        lastfmKeySet    => ($prefs->get('lastfmApiKey') || '') ne '' ? 1 : 0,
        lbEnabled       => _intPref($prefs->get('lbEnabled'), 0),
        lbUser          => _stringPref($prefs->get('lbUser'), ''),
        lbTokenSet      => ($prefs->get('lbToken') || '') ne '' ? 1 : 0,
    };
}


sub _cliCommand {
    my $request = shift;

    if ($request->isNotCommand([ [ 'lmskin' ] ])) {
        $request->setStatusBadDispatch();
        return;
    }

    my $cmd = $request->getParam('_cmd');
    if ($request->paramUndefinedOrNotOneOf($cmd, [ 'bootstrap', 'info', 'browsemodes', 'extras',
                                                   'apps', 'scan-progress', 'scantypes', 'playersettings',
                                                   'transferqueue',
                                                   'focus', 'similar', 'warm',
                                                   'album-index', 'album-urls',
                                                   'wrapped-stats', 'wrapped-history', 'wrapped-clear',
                                                   'ai-generate', 'ai-result', 'ai-replace', 'ai-play',
                                                   'ai-save', 'ai-cancel', 'charts-generate',
                                                   'online-favs',
                                                   'feature-prefs', 'set-feature-pref' ])) {
        $request->setStatusBadParams();
        return;
    }

    # ---------------------------------------------------------------- bootstrap
    # One round trip at start-up. This replaces the [% PERL %] block Material
    # inlines into its index.html, so our index.html can stay a static file.
    if ($cmd eq 'bootstrap') {
        my $os = eval { Slim::Utils::OSDetect::details() } || {};

        my %config = (
            version    => $pluginVersion,
            lmsVersion => $::VERSION,
            lmsNumeric => $lmsVersion,
            title      => _windowTitle(),
            os         => $os->{osName} || '',
            hostname   => Slim::Utils::Network::hostName() || '',
            prefs      => {
                gridSize         => _intPref($prefs->get('gridSize'), 180),
                pageSize         => _intPref($prefs->get('pageSize'), 250),
                setPlayerLibrary => _intPref($prefs->get('setPlayerLibrary'), 0),
                accent           => _stringPref($prefs->get('accent'), 'a0b0ff'),
                blur             => _intPref($prefs->get('blur'), 24),
            },
            server     => {
                language              => $serverprefs->get('language') || 'en',
                timeFormat            => $serverprefs->get('timeFormat') || '%H:%M',
                useUnifiedArtistsList => $serverprefs->get('useUnifiedArtistsList') ? 1 : 0,
                ignoreReleaseTypes    => $serverprefs->get('ignoreReleaseTypes') ? 1 : 0,
                groupByReleaseType    => $serverprefs->get('groupArtistAlbumsByReleaseType') ? 1 : 0,
                variousArtists        => $serverprefs->get('variousArtistsString') || 'Various Artists',
            },
            plugins    => { map { $_ => _pluginEnabled($PARTNER_PLUGINS{$_}) } keys %PARTNER_PLUGINS },
            ai         => {
                enabled    => _intPref($prefs->get('aiEnabled'), 1),
                configured => ($prefs->get('aiModel') || '') ne '' ? 1 : 0,
                model      => _stringPref($prefs->get('aiModel'), ''),
            },
        );

        $request->addResult('config', Encode::decode_utf8(encode_json(\%config)));
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- info
    if ($cmd eq 'info') {
        my $os   = eval { Slim::Utils::OSDetect::details() } || {};
        my $info = [
            { id => 'version',  label => string('INFORMATION_VERSION'),         text => "$::VERSION - $::REVISION @ $::BUILDDATE" },
            { id => 'host',     label => string('INFORMATION_HOSTNAME'),        text => Slim::Utils::Network::hostName() },
            { id => 'ip',       label => string('INFORMATION_SERVER_IP'),       text => Slim::Utils::Network::serverAddr() },
            { id => 'os',       label => string('INFORMATION_OPERATINGSYSTEM'), text => ($os->{osName} || '') . ' - ' . ($serverprefs->get('language') || '') },
            { id => 'arch',     label => string('INFORMATION_ARCHITECTURE'),    text => $os->{osArch} || '' },
            { id => 'perl',     label => 'Perl',                                text => "$Config::Config{version} - $Config::Config{archname}" },
        ];
        $request->addResult('info', Encode::decode_utf8(encode_json($info)));
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- browsemodes
    # Every plugin that registers a browse mode in LMS shows up here for free.
    if ($cmd eq 'browsemodes') {
        my $unified = $serverprefs->get('useUnifiedArtistsList');
        my $cnt     = 0;
        my @nodes   = @{ Slim::Menu::BrowseLibrary->_getNodeList() || [] };

        foreach my $node (@nodes) {
            next if $node->{id} eq 'myMusicSearch';
            if ($unified) {
                next if $node->{id} eq 'myMusicArtistsAllArtists' || $node->{id} eq 'myMusicArtistsAlbumArtists';
            } else {
                next if $node->{id} eq 'myMusicArtists';
            }
            $request->addResultLoop('modes_loop', $cnt, 'id',     $node->{id});
            $request->addResultLoop('modes_loop', $cnt, 'text',   string($node->{name}));
            $request->addResultLoop('modes_loop', $cnt, 'weight', $node->{weight} || 0);
            $request->addResultLoop('modes_loop', $cnt, 'count',  $node->{count} || 0);
            my $icon = $node->{jiveIcon} || $node->{icon};
            $request->addResultLoop('modes_loop', $cnt, 'icon', $icon) if $icon;
            $cnt++;
        }

        $request->addResult('count', $cnt);
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- extras
    # "%Slim::Web::Pages::additionalLinks" is LMS's documented way for plugins to
    # add pages. Surfacing them keeps third-party plugin screens reachable.
    if ($cmd eq 'extras') {
        my ($icons, %pages);
        while (my ($menu, $items) = each %Slim::Web::Pages::additionalLinks) {
            $icons = $items if $menu eq 'icons';
            next unless $menu eq 'plugins' || $menu eq 'browseiPeng';
            $pages{$_} = $items->{$_} for keys %{ $items || {} };
        }

        my $cnt = 0;
        foreach my $key (sort keys %pages) {
            $request->addResultLoop('extras_loop', $cnt, 'id',    $key);
            $request->addResultLoop('extras_loop', $cnt, 'url',   $pages{$key});
            $request->addResultLoop('extras_loop', $cnt, 'title', string($key));
            $request->addResultLoop('extras_loop', $cnt, 'icon',  $icons->{$key}) if $icons && $icons->{$key};
            $cnt++;
        }

        $request->addResult('count', $cnt);
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- apps
    # Tidal / Qobuz / Spotify are XMLBrowser apps. They appear here as soon as
    # their LMS plugin is installed - no client-side special-casing.
    if ($cmd eq 'apps') {
        my $apps = Slim::Plugin::Base->nonSNApps() || [];
        my $cnt  = 0;

        for my $app (@$apps) {
            next unless $app->can('tag');
            my $tag = eval { $app->tag() };
            next unless $tag;
            $request->addResultLoop('item_loop', $cnt, 'text', Slim::Utils::Strings::getString(eval { $app->getDisplayName() }) || $tag);
            my $icon = eval { $app->_pluginDataFor('icon') };
            $request->addResultLoop('item_loop', $cnt, 'icon', $icon) if $icon;
            $request->addResultLoop('item_loop', $cnt, 'type', 'redirect');
            $request->addResultLoop('item_loop', $cnt, 'actions',
                { go => { cmd => [ $tag, 'items' ], params => { menu => $tag } } });
            $cnt++;
        }

        $request->addResult('count', $cnt);
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- scan-progress
    if ($cmd eq 'scan-progress') {
        if (Slim::Schema::hasLibrary()) {
            if (Slim::Music::Import->stillScanning()) {
                $request->addResult('rescan', 1);
                if (my $p = Slim::Schema->rs('Progress')->search({ type => 'importer', active => 1 })->first) {
                    my $name = $p->name || '';
                    $name =~ s{(.*)\|}{};
                    $request->addResult('progressname', $request->string($name . '_PROGRESS'));
                    $request->addResult('progressdone',  $p->done  || 0);
                    $request->addResult('progresstotal', $p->total || 0);
                }
            } else {
                $request->addResult('lastscan', Slim::Music::Import->lastScanTime() || 0);
            }
        }
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- scantypes
    # Rescan menu entries, straight from the importer (names localized by LMS).
    if ($cmd eq 'scantypes') {
        my $cnt = 0;
        my $scanTypes = Slim::Music::Import->getScanTypes();
        foreach ( map {
                {
                        name => $scanTypes->{$_}->{name},
                        cmd  => $scanTypes->{$_}->{cmd}
                }
        } sort keys %$scanTypes ) {
            $request->setResultLoopHash('item_loop', $cnt++, {
                    name => string($_->{name}),
                    cmd  => $_->{cmd} });
        }
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- playersettings
    # Per-player icon/color store, mirroring Material's playersettings. M2's
    # player management UI is the consumer; the server side lands first.
    if ($cmd eq 'playersettings') {
        my $id     = $request->getParam('id');
        my $client = Slim::Player::Client::getClient($id);
        if (!$client) {
            $request->setStatusBadParams();
            return;
        }
        if (defined $request->getParam('icon')) {
            $prefs->client($client)->set('icon', $request->getParam('icon'));
        }
        if (defined $request->getParam('color')) {
            $prefs->client($client)->set('color', $request->getParam('color'));
        }
        $request->addResult('icon',  $prefs->client($client)->get('icon')  || '');
        $request->addResult('color', $prefs->client($client)->get('color') || '');
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- transferqueue
    if ($cmd eq 'transferqueue') {
        _transferQueue($request);
        return;
    }

    # ---------------------------------------------------------------- focus
    if ($cmd eq 'focus') {
        _focus($request);
        return;
    }

    # ---------------------------------------------------------------- warm
    if ($cmd eq 'warm') {
        _scheduleWarm(1);
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- album-index
    if ($cmd eq 'album-index') {
        _albumIndex($request);
        return;
    }

    if ($cmd eq 'album-urls') {
        _albumUrls($request);
        return;
    }

    # ---------------------------------------------------------------- similar
    if ($cmd eq 'similar') {
        _similar($request);
        return;
    }

    # ---------------------------------------------------------------- wrapped
    if ($cmd eq 'wrapped-stats') {
        my $s = eval { Plugins::LMSkin::PlayLog::stats($request->getParam('range')) };
        if (!$s) {
            $request->addResult('error', "$@");
        } else {
            $request->addResult('stats', Encode::decode_utf8(encode_json($s)));
        }
        $request->setStatusDone();
        return;
    }

    if ($cmd eq 'wrapped-history') {
        my %rows = eval { Plugins::LMSkin::PlayLog::history(
            range => $request->getParam('range'),
            offset => _intPref($request->getParam('offset'), 0),
            limit  => _intPref($request->getParam('limit'), 50),
        ) };
        if ($@) {
            $request->addResult('error', "$@");
        } else {
            $request->addResult('total', $rows{total} // 0);
            $request->addResult('rows',  Encode::decode_utf8(encode_json($rows{rows} || [])));
        }
        $request->setStatusDone();
        return;
    }

    if ($cmd eq 'wrapped-clear') {
        if (!$request->getParam('confirm')) {
            $request->setStatusBadParams();
            return;
        }
        eval { Plugins::LMSkin::PlayLog::clear() };
        if ($@) {
            $request->addResult('error', "$@");
        }
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- online-favs
    # The heart-state index for TIDAL/Qobuz/Spotify favorites (see _favorite):
    # LMS's own favorites browse never round-trips raw service URLs.
    if ($cmd eq 'online-favs') {
        my $favs = $prefs->get('onlineFavs') || {};
        my @items = map {
            { url => $_, title => $favs->{$_}->{title}, type => $favs->{$_}->{type} }
        } sort {
            ($favs->{$b}->{ts} || 0) <=> ($favs->{$a}->{ts} || 0)
        } keys %$favs;
        $request->addResult('items', Encode::decode_utf8(encode_json(\@items)));
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- feature prefs
    # The skin's Settings dialog configures Studio/Wrapped/scrobbling here.
    # Reads are masked (never the key/token); writes go through a strict
    # whitelist so the client can only touch feature prefs, not anything else.
    if ($cmd eq 'feature-prefs') {
        $request->addResult('prefs', Encode::decode_utf8(encode_json(_featurePrefs())));
        $request->setStatusDone();
        return;
    }

    if ($cmd eq 'set-feature-pref') {
        my $name  = $request->getParam('pref')  // '';
        my $value = $request->getParam('value');
        $value = '' unless defined $value;

        my %validate = (
            aiEnabled       => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            aiBaseUrl       => sub { $_[0] eq '' || $_[0] =~ m{^https?://} ? 1 : 0 },
            aiApiKey        => sub { 1 },
            aiModel         => sub { 1 },
            aiTemperature   => sub { $_[0] =~ /^[01](\.\d+)?$|^2(\.0+)?$/ ? 1 : 0 },
            aiMaxCandidates => sub { $_[0] =~ /^\d+$/ && $_[0] >= 100 && $_[0] <= 3000 ? 1 : 0 },
            aiTimeout       => sub { $_[0] =~ /^\d+$/ && $_[0] >= 15 && $_[0] <= 600 ? 1 : 0 },
            aiOnlineResolve => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            aiOnlineQobuz   => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            aiOnlineTidal   => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            aiOnlineSpotty  => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            aiOnlineLimit   => sub { $_[0] =~ /^\d+$/ && $_[0] >= 5 && $_[0] <= 100 ? 1 : 0 },
            onlineFavorites => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            lastfmApiKey    => sub { 1 },
            lbEnabled       => sub { $_[0] =~ /^[01]$/ ? 1 : 0 },
            lbToken         => sub { 1 },
            lbUser          => sub { $_[0] =~ m{^[A-Za-z0-9_.\- ]*$} ? 1 : 0 },
        );

        my $check = $validate{$name};
        if (!$check || !$check->($value)) {
            $request->addResult('error', "invalid or out-of-range pref '$name'");
            $request->setStatusDone();
            return;
        }

        $prefs->set($name, $value);
        $request->addResult('prefs', Encode::decode_utf8(encode_json(_featurePrefs())));
        $request->setStatusDone();
        return;
    }

    # ---------------------------------------------------------------- studio (AI) + charts
    if ($cmd =~ /^(ai-|charts-generate)/) {
        my $ok = eval { require Plugins::LMSkin::Ai; 1 };
        if (!$ok) {
            $request->addResult('error', "AI module failed to load: $@");
            $request->setStatusDone();
            return;
        }
        Plugins::LMSkin::Ai::handle($cmd, $request);
        return;
    }

    $request->setStatusBadParams();
}

# ---------------------------------------------------------------- focus (facets)
#
# Roon's Focus panel needs value/count pairs per facet. LMS exposes no facet API,
# so this is the one place in the plugin that queries SQLite directly: one GROUP BY
# per facet, counting distinct albums. Everything else goes through stock commands
# so plugin-provided libraries and virtual libraries keep working.
#
#   lmskin focus facet:genre filters:'format=flac;year=1975' limit:40
#
# filters is a ';'-separated key=value list with URI-escaped values.

my %FACET_SQL = (
    # LMS 9 links genres to tracks through genre_track, not a column on tracks.
    genre => q{
        SELECT g.name AS value, COUNT(DISTINCT t.album) AS cnt
          FROM tracks t
          JOIN genre_track gt ON gt.track = t.id
          JOIN genres g       ON g.id = gt.genre
         WHERE t.album IS NOT NULL AND g.id > 0 __WHERE__
      GROUP BY g.id
      ORDER BY cnt DESC, value ASC
         LIMIT ?
    },
    decade => q{
        SELECT (CAST(t.year / 10 AS INTEGER) * 10) AS value, COUNT(DISTINCT t.album) AS cnt
          FROM tracks t
         WHERE t.album IS NOT NULL AND t.year > 0 __WHERE__
      GROUP BY value
      ORDER BY value ASC
         LIMIT ?
    },
    format => q{
        SELECT UPPER(t.content_type) AS value, COUNT(DISTINCT t.album) AS cnt
          FROM tracks t
         WHERE t.album IS NOT NULL AND t.content_type IS NOT NULL __WHERE__
      GROUP BY t.content_type
      ORDER BY cnt DESC, value ASC
         LIMIT ?
    },
    # Rating and play-count facets are deliberately absent: LMS only stores them
    # in the persistent table when statistics are enabled (a plugin), so on a
    # default install there is nothing to count.
);

sub _focusFilterSql {
    my ($filters) = @_;
    my (@sql, @bind);

    if (my $g = $filters->{genre}) {
        push @sql,  'AND t.id IN (SELECT gt.track FROM genre_track gt'
                  . ' JOIN genres gg ON gg.id = gt.genre WHERE gg.name = ?)';
        push @bind, $g;
    }

    if (defined $filters->{decade} && $filters->{decade} =~ /^(\d+)$/) {
        my $start = int($1 / 10) * 10;
        push @sql,  'AND t.year >= ? AND t.year <= ?';
        push @bind, $start, $start + 9;
    }

    if (my $f = $filters->{format}) {
        push @sql,  'AND t.content_type = ?';
        push @bind, lc($f);
    }

    return (join(' ', @sql), @bind);
}

sub _focus {
    my $request = shift;
    my $facet   = $request->getParam('facet') || 'genre';

    if (!$FACET_SQL{$facet}) {
        $request->setStatusBadParams();
        return;
    }

    my %filters;
    if (my $raw = $request->getParam('filters')) {
        foreach my $pair (split(/;/, $raw)) {
            my ($k, $v) = split(/=/, $pair, 2);
            next if !$k || !defined $v || $v eq '';
            $filters{$k} = uri_unescape($v);
        }
        delete $filters{$facet};    # a facet never filters itself
    }

    my $limit = int($request->getParam('limit') || 40);
    $limit = 1   if $limit < 1;
    $limit = 100 if $limit > 100;

    my ($where, @bind) = _focusFilterSql(\%filters);
    my $sql = $FACET_SQL{$facet};
    $sql =~ s/\Q__WHERE__\E/$where/;

    my $dbh = Slim::Schema->dbh;
    my $ok  = eval {
        my $sth = $dbh->prepare($sql);
        $sth->execute(@bind, $limit);
        my $rows = $sth->fetchall_arrayref({});
        my $cnt  = 0;
        foreach my $row (@{ $rows || [] }) {
            next if !defined $row->{value} || $row->{value} eq '';
            $row->{value} = Encode::decode_utf8($row->{value});
            $request->addResultLoop('facet_loop', $cnt, 'value', $row->{value});
            $request->addResultLoop('facet_loop', $cnt, 'count', int($row->{cnt}));
            $cnt++;
        }
        $request->addResult('count', $cnt);
        1;
    };

    if (!$ok) {
        $log->error("focus '$facet' failed: $@");
        $request->addResult('error', "$@");
    }

    $request->setStatusDone();
}

# ---------------------------------------------------------------- album-index
#
# Focus needs, for every album, its genre ids, its best audio format and its
# track ids (to resolve "played" against the browser's local play log). Asking
# LMS for the full track list instead cost ~137 JSON-RPC round trips of 1000
# rows with the whole tag alphabet - the heaviest thing the UI did. Here the
# same data is one GROUP BY over the track tables: ~0.4 s of SQL and ~1.3 MB
# of JSON, computed once per scan and then served from memory.

my $ALBUM_INDEX = { scan => -1, data => '' };

sub _albumIndex {
    my $request  = shift;
    my $scan     = Slim::Music::Import->lastScanTime() || 0;
    my $scanning = Slim::Music::Import->stillScanning;

    if (!$scanning && $ALBUM_INDEX->{scan} eq $scan) {
        $request->addResult('data', $ALBUM_INDEX->{data});
        $request->setStatusDone();
        return;
    }

    my $ok = eval {
        my $sth = Slim::Schema->dbh->prepare(q{
            SELECT t.album,
                   COALESCE(MAX(t.samplesize), 0),
                   COALESCE(MAX(t.samplerate), 0),
                   COALESCE(GROUP_CONCAT(DISTINCT gt.genre), ''),
                   GROUP_CONCAT(t.id)
              FROM tracks t
              LEFT JOIN genre_track gt ON gt.track = t.id
             WHERE t.album IS NOT NULL
             GROUP BY t.album
        });
        $sth->execute;
        my @rows;
        while (my $r = $sth->fetchrow_arrayref) {
            push @rows, [ int($r->[0]), int($r->[1]), int($r->[2]), $r->[3] || '', $r->[4] || '' ];
        }
        my $data = Encode::decode_utf8(encode_json({ scan => "$scan", albums => \@rows }));
        # A scan rewrites these tables; only memoize a stable answer.
        $ALBUM_INDEX = { scan => $scan, data => $data } if !$scanning;
        $request->addResult('data', $data);
        1;
    };

    if (!$ok) {
        $log->error("album-index failed: $@");
        $request->addResult('error', "$@");
    }
    $request->setStatusDone();
}

# Track urls for a set of albums, for playlist export. Kept out of the index
# above: the url column alone is an order of magnitude larger than every id.
sub _albumUrls {
    my $request = shift;
    my @ids = grep { /^\d+$/ } split(/,/, $request->getParam('albums') || '');
    if (!@ids) {
        $request->setStatusBadParams();
        return;
    }
    splice(@ids, 5000) if @ids > 5000;    # bound the query and the response

    my $ok = eval {
        my $sth = Slim::Schema->dbh->prepare(
            'SELECT url FROM tracks WHERE album IN (' . join(',', @ids) . ')'
          . ' ORDER BY album, disc, tracknum');
        $sth->execute;
        my @urls;
        while (my $r = $sth->fetchrow_arrayref) {
            push @urls, Encode::decode_utf8($r->[0]) if defined $r->[0] && $r->[0] ne '';
        }
        $request->addResult('urls',  Encode::decode_utf8(encode_json(\@urls)));
        $request->addResult('count', scalar @urls);
        1;
    };

    if (!$ok) {
        $log->error("album-urls failed: $@");
        $request->addResult('error', "$@");
    }
    $request->setStatusDone();
}

# ---------------------------------------------------------------- browse warm
#
# The first browse query of each shape after a restart or a rescan is answered
# from a cold cache: SQL is compiled and the album/artist/genre pages are
# loaded. On this 136k-track library we measured first-visit list queries
# taking seconds while the server was otherwise busy. Running the exact
# commands the UI issues - one at a time, two seconds apart, from a timer
# instead of a user click - moves that cost off the first navigation.
#
# The params must match the client byte for byte (see the commands in
# client/src/lib/state/{library,browse}.svelte.ts), or LMS treats the request
# as a different query and pays the cold cost again.

my @WARM_QUERIES = (
    [ 'playlists', 0, 500 ],
    [ 'genres',    0, 500 ],
    [ 'artists',   0, 250, 'tags:4' ],
    [ 'albums',    0, 250, 'sort:artistalbum', 'tags:jalycEKS' ],
    [ 'albums',    0, 250, 'sort:album',       'tags:jalycEKS' ],
    [ 'albums',    0,  24, 'sort:new',         'tags:jalycEKS' ],
    [ 'lmskin', 'album-index' ],
);

my @warmQueue;

sub _scheduleWarm {
    my $delay = shift || 20;
    @warmQueue = @WARM_QUERIES;
    Slim::Utils::Timers::forgetTimer($WARM_OBJ);
    Slim::Utils::Timers::setTimer($WARM_OBJ, Time::HiRes::time() + $delay, \&_warmNext);
}

sub _warmNext {
    # A scan rewrites the tables these queries read; wait for it to finish.
    if (Slim::Music::Import->stillScanning) {
        Slim::Utils::Timers::setTimer($WARM_OBJ, Time::HiRes::time() + 120, \&_warmNext);
        return;
    }

    my $next = shift @warmQueue;
    return if !$next;

    eval { Slim::Control::Request::executeRequest(undef, $next) };
    $log->debug("warm @{$next} failed: $@") if $@;

    Slim::Utils::Timers::setTimer($WARM_OBJ, Time::HiRes::time() + 2, \&_warmNext);
}

sub _onRescanDone {
    _scheduleWarm(10);
}

# ---------------------------------------------------------------- transfer queue
#
# Pure orchestration over stock LMS commands: sync, unsync, save, clear, index.
# The ordering here matters - replacing it with something "tidier" breaks synced
# and group players, so it is carried over from Material largely intact.

sub _transferQueue {
    my $request = shift;

    my $fromId = $request->getParam('from');
    my $toId   = $request->getParam('to');
    my $mode   = $request->getParam('mode');

    if (!$fromId || !$toId || !$mode || $fromId eq $toId || $mode !~ /^(move|copy|swap)$/) {
        $request->setStatusBadParams();
        return;
    }

    my $from = Slim::Player::Client::getClient($fromId);
    my $to   = Slim::Player::Client::getClient($toId);
    if (!$from || !$to) {
        $request->setStatusBadParams();
        return;
    }

    my $fromWasPlaying  = $from->isPlaying();
    my $toWasPlaying    = $to->isPlaying();
    my $fromQueueIndex  = Slim::Player::Source::playingSongIndex($from);
    my $toQueueIndex    = Slim::Player::Source::playingSongIndex($to);
    my $srcIsGroup      = $from->model eq 'group';
    my $groupToMember   = 0;

    my @sourceBuddies;
    if ($from->isSynced()) {
        @sourceBuddies = $from->syncedWith();
        for my $buddy (@sourceBuddies) {
            next unless $buddy->id() eq $toId;
            if ($srcIsGroup && $mode eq 'move') {
                $groupToMember = 1;
                last;
            }
            $request->addResult('error', 'Players are already synced');
            $request->setStatusDone();
            return;
        }
    }

    my @destBuddies = $to->isSynced() ? $to->syncedWith() : ();

    $to->execute([ 'power', 1 ]) unless $to->power;

    if ($mode eq 'swap') {
        my $fromPl = 'lmskin-swap-' . $fromId;
        my $toPl   = 'lmskin-swap-' . $toId;
        $fromPl =~ s/:/_/g;
        $toPl   =~ s/:/_/g;

        $from->execute([ 'playlist', 'save', $fromPl ]);
        my $fromPlObj = Slim::Schema->single('Playlist', { title => $fromPl });
        if (!blessed($fromPlObj)) {
            $request->setStatusBadParams();
            return;
        }

        $to->execute([ 'playlist', 'save', $toPl ]);
        my $toPlObj = Slim::Schema->single('Playlist', { title => $toPl });
        if (!blessed($toPlObj)) {
            Slim::Control::Request::executeRequest(undef, [ 'playlists', 'delete', 'playlist_id:' . $fromPlObj->id ]);
            $request->setStatusBadParams();
            return;
        }

        $from->execute([ 'playlist', 'clear' ]);
        $from->execute([ 'playlistcontrol', 'cmd:add', 'playlist_id:' . $toPlObj->id ]);
        $to->execute([ 'playlist', 'clear' ]);
        $to->execute([ 'playlistcontrol', 'cmd:add', 'playlist_id:' . $fromPlObj->id ]);

        Slim::Control::Request::executeRequest(undef, [ 'playlists', 'delete', 'playlist_id:' . $fromPlObj->id ]);
        Slim::Control::Request::executeRequest(undef, [ 'playlists', 'delete', 'playlist_id:' . $toPlObj->id ]);
    } else {
        # Syncing copies the queue onto the destination; unsyncing leaves it there.
        $from->execute([ 'sync', $toId ]);
        if (exists $INC{'Slim/Plugin/RandomPlay/Plugin.pm'} && (my $mix = Slim::Plugin::RandomPlay::Plugin::active($from))) {
            $to->execute([ 'playlist', 'addtracks', 'listRef', [ 'randomplay://' . $mix ] ]);
        }
        $to->execute([ 'now-playing' ]);
        $from->execute([ 'sync', '-' ]);
    }

    if ($groupToMember) {
        $to->execute([ 'sync', '-' ]);
        for my $buddy (@destBuddies) {
            $buddy->execute([ 'playlist', 'clear' ]);
            $buddy->execute([ 'power', 0 ]);
        }
    } else {
        $to->execute([ 'sync', $_->id() ])   for @destBuddies;
        $from->execute([ 'sync', $_->id() ]) for @sourceBuddies;
    }

    if ($mode eq 'move') {
        $from->execute([ 'playlist', 'clear' ]);
        $from->execute([ 'power', 0 ]);
    }

    if ($mode eq 'swap') {
        $to->execute([ 'playlist', 'index', $fromQueueIndex ]) if $fromWasPlaying;
        $from->execute([ 'playlist', 'index', $toQueueIndex ]) if $toWasPlaying;
    } elsif ($to->isSynced() || $to->model eq 'group') {
        # Sync can land a step behind; a power cycle settles it. A group player
        # needs two cycles - hence the nested timer.
        $to->execute([ 'power', 0 ]);
        Slim::Utils::Timers::setTimer($to, Time::HiRes::time() + 1, sub {
            my ($client, $resume) = @_;
            $client->execute([ 'power', 1 ]);
            if ($client->model eq 'group') {
                $client->execute([ 'power', 0 ]);
                Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 1, sub {
                    my ($c, $r) = @_;
                    $c->execute([ 'power', 1 ]);
                    $c->execute([ 'play' ]) if $r;
                }, $resume);
            } elsif ($resume) {
                $client->execute([ 'play' ]);
            }
        }, $fromWasPlaying);
    } elsif ($fromWasPlaying) {
        $to->execute([ 'play' ]);
    }

    $request->setStatusDone();
}

# ---------------------------------------------------------------- similar artists
#
# Last.fm's artist.getSimilar, cached on disk for 90 days. Results feed the
# "Discover" row on an artist page.

sub _similar {
    my $request = shift;
    my $artist  = $request->getParam('artist');
    if (!$artist) {
        $request->setStatusBadParams();
        return;
    }

    my $cacheRoot = $serverprefs->get('cachedir') || Slim::Utils::Prefs::dir();
    my $prefsDir  = File::Spec->catdir(Slim::Utils::Prefs::dir(), 'lmskin', 'similar-artists');
    my $cacheDir  = File::Spec->catdir($cacheRoot, 'lmskin', 'similar-artists');

    my $key = lc($artist);
    $key =~ s{[/\:.(){}\[\]]}{}g;
    $key = 'x' if $key eq '';

    # A file in the prefs folder is user-provided, so never expire it.
    my $ignoreAge = 0;
    my $filePath  = File::Spec->catfile($prefsDir, $key . '.json');
    if (-e $filePath) {
        $ignoreAge = 1;
    } else {
        $filePath = File::Spec->catfile($cacheDir, $key . '.json');
    }

    if (-e $filePath) {
        my $content = _readFile($filePath);
        if ($content && _handleSimilarArtists($request, $content, 0, $key, $cacheDir, $ignoreAge)) {
            $request->setStatusDone();
            return;
        }
    }

    $request->setStatusProcessing();

    my $ua = Slim::Utils::Misc::userAgentString();
    $ua =~ s{iTunes/4\.7\.1}{Mozilla/5.0};

    my $url = 'https://ws.audioscrobbler.com/2.0/?api_key=' . $LASTFM_API_KEY
            . '&method=artist.getSimilar&autocorrect=1&format=json&limit=25&artist='
            . uri_escape_utf8($artist);

    Slim::Networking::SimpleAsyncHTTP->new(
        sub {
            my $response = shift;
            _handleSimilarArtists($request, $response->content, 1, $key, $cacheDir, $ignoreAge);
            $request->setStatusDone();
        },
        sub {
            # Offline or rate-limited: fall back to the cached copy, however old.
            if (-e $filePath) {
                my $content = _readFile($filePath);
                _handleSimilarArtists($request, $content, 0, $key, $cacheDir, 1) if $content;
            }
            $request->setStatusDone();
        },
        { timeout => 15 }
    )->get($url, 'User-Agent' => $ua);
}

sub _handleSimilarArtists {
    my ($request, $content, $save, $key, $cacheDir, $ignoreAge) = @_;

    my $decoded = eval { decode_json($content) };
    return 0 unless ref $decoded eq 'HASH';

    my $data = $decoded->{similarartists};
    return 0 unless ref $data eq 'HASH' && ref $data->{artist} eq 'ARRAY';

    my @names = map { ref $_ eq 'HASH' ? $_->{name} : $_ } @{ $data->{artist} };
    @names = grep { defined $_ && $_ ne '' } @names;

    # Expired cache, and the network call that would refresh it is still pending:
    # report a miss so the caller fetches. save=1 always writes through.
    my $now = time();
    if (!$save && !$ignoreAge && $decoded->{time} && ($now - $decoded->{time}) >= $MAX_CACHE_AGE) {
        return 0;
    }

    my $cnt = 0;
    foreach my $name (@names) {
        $request->addResultLoop('similar_loop', $cnt++, 'artist', $name);
    }
    $request->addResult('count', $cnt);

    if ($save) {
        make_path($cacheDir) unless -d $cacheDir;
        if (open(my $fh, '>:encoding(UTF-8)', File::Spec->catfile($cacheDir, $key . '.json'))) {
            print $fh encode_json({ time => $now, similarartists => \@names });
            close($fh);
        }
    }

    return $cnt;
}

sub _readFile {
    my ($path) = @_;
    open(my $fh, '<:encoding(UTF-8)', $path) or return undef;
    local $/;
    my $content = <$fh>;
    close($fh);
    return $content;
}

# ---------------------------------------------------------------- client commands

sub _cliClientCommand {
    my $request = shift;

    if ($request->isNotCommand([ [ 'lmskin-client' ] ])) {
        $request->setStatusBadDispatch();
        return;
    }

    my $cmd    = $request->getParam('_cmd');
    my $client = $request->client();

    if ($request->paramUndefinedOrNotOneOf($cmd, [ 'set-lib', 'sort-queue', 'remove-queue', 'favorite' ])) {
        $request->setStatusBadParams();
        return;
    }

    # ---------------------------------------------------------------- favorite
    # Online-service hearts: parse the item URL and forward to the owning
    # plugin's native favorite API (TIDAL/Qobuz/Spotify), so the like lands
    # in the service account itself. See _favorite below.
    if ($cmd eq 'favorite') {
        _favorite($request, $client);
        return;
    }

    # Per-player virtual library. The server pref drives what the player sees;
    # our plugin pref remembers it so it can be restored after the queue clears.
    if ($cmd eq 'set-lib') {
        my $id = $request->getParam('id');

        if ($request->getParam('store')) {
            my $prev = $serverprefs->client($client)->get('libraryId');
            $prefs->client($client)->set('libraryId', $prev) if $prev;
        }

        if (!$id && $request->getParam('restore')) {
            $id = $prefs->client($client)->get('libraryId') || '';
        }

        if ($id) {
            $serverprefs->client($client)->set('libraryId', $id);
        } else {
            $serverprefs->client($client)->remove('libraryId');
        }

        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 0.1, sub {
            Slim::Schema->totals($client);
        });
        $request->setStatusDone();
        return;
    }

    if ($cmd eq 'sort-queue') {
        my @tracks = Slim::Player::Playlist::songs($client, 0, Slim::Player::Playlist::count($client));
        if (scalar(@tracks) > 1) {
            Slim::Player::Playlist::stopAndClear($client);
            @tracks = _sortTracks(\@tracks, $request->getParam('order'));
            Slim::Player::Playlist::addTracks($client, \@tracks, 0);
            $client->currentPlaylistModified(1);
            $client->currentPlaylistUpdateTime(Time::HiRes::time());
            Slim::Player::Playlist::refreshPlaylist($client);
        }
        $request->setStatusDone();
        return;
    }

    if ($cmd eq 'remove-queue') {
        my $indexes = $request->getParam('indexes');
        if (defined $indexes) {
            foreach my $idx (split(/,/, $indexes)) {
                Slim::Player::Playlist::removeTrack($client, $idx);
            }
            $client->currentPlaylistModified(1);
            $client->currentPlaylistUpdateTime(Time::HiRes::time());
            Slim::Player::Playlist::refreshPlaylist($client);
        }
        $request->setStatusDone();
        Slim::Control::Request::notifyFromArray($client, [ 'playlist', 'delete', '_index' ]);
        return;
    }
}

# ---------------------------------------------------------------- online favorites
#
# The skin's heart buttons mirror every online favorite into LMS's favorites
# store (that mirror drives heart state), and this bridge forwards the same
# action to the streaming service itself so the like lands in the user's
# TIDAL/Qobuz/Spotify account. The client sends the item URL:
#
#   lmskin-client favorite action:add url:tidal://track:12345
#
# URL shapes (verified against the installed plugins):
#   tidal://track:<id> | tidal://album:<id> | tidal://artist:<id>
#   qobuz://track:<id>.qbz | qobuz://album:<id>.qbz | qobuz://artist:<id>.qbz
#   spotify:track:<id> | spotify:album:<id> | spotify:artist:<id>
#
# The service API handlers resolve the account from a player, which is why
# this lives on lmskin-client (a player-bound command) rather than lmskin.

sub _parseFavUrl {
    my ($url) = @_;

    if ($url =~ m{^tidal://(track|album|artist):(\w+)}) {
        return { service => 'tidal', type => $1, id => $2 };
    }
    # Play-url form emitted for tracks: tidal://<id>.<format>
    if ($url =~ m{^tidal://(\d+)}) {
        return { service => 'tidal', type => 'track', id => $1 };
    }
    if ($url =~ m{^qobuz://(?:([a-z]+):)?([0-9a-z]+)(?:\.[0-9a-z]+)?$}i) {
        return { service => 'qobuz', type => $1 || 'track', id => $2 };
    }
    if ($url =~ m{^spotify:(track|album|artist):(\w+)}) {
        return { service => 'spotify', type => $1, id => $2 };
    }
    return undef;
}

sub _favorite {
    my ($request, $client) = @_;

    my $url    = $request->getParam('url') || '';
    my $action = $request->getParam('action') || 'add';
    $action = $action eq 'del' ? 'del' : 'add';

    my $fail = sub {
        my ($msg) = @_;
        $request->addResult('error', $msg);
        $request->addResult('favorited', $action eq 'add' ? 0 : 1);
        $request->setStatusDone();
    };

    my $item = _parseFavUrl($url);
    return $fail->("unsupported favorite url") unless $item;
    return $fail->("not signed in") unless $client;

    my %mods = (
        tidal   => 'Plugins::TIDAL::Plugin',
        qobuz   => 'Plugins::Qobuz::Plugin',
        spotify => 'Plugins::Spotty::Plugin',
    );
    my $mod = $mods{ $item->{service} };
    return $fail->("$item->{service} plugin not enabled") unless _pluginEnabled($mod);

    my $record = sub {
        my $favs = $prefs->get('onlineFavs') || {};
        if ($action eq 'add') {
            $favs->{$url} = {
                title => scalar($request->getParam('title')) || $url,
                type  => scalar($request->getParam('favtype')) || 'audio',
                ts    => time(),
            };
        } else {
            delete $favs->{$url};
        }
        $prefs->set('onlineFavs', $favs);
    };

    my $done = sub {
        my ($err) = @_;
        if (defined $err) {
            $fail->($err);
        } else {
            $record->();
            $request->addResult('favorited', $action eq 'add' ? 1 : 0);
            $request->setStatusDone();
        }
    };

    # native:0 = settings toggle "like in service" is off — record locally
    # only, without touching the service API.
    if (($request->getParam('native') // '1') eq '0') {
        $done->();
        return;
    }

    # The plugin APIs are async: hold the request open until the callback
    # fires, otherwise the RPC layer replies with an empty result.
    $request->setStatusProcessing();

    my $ok = eval { _dispatchFavorite($client, $item, $action, $done); 1 };
    $fail->("favorite failed: $@") unless $ok;
}

sub _dispatchFavorite {
    my ($client, $item, $action, $done) = @_;

    my $verb = $action eq 'add' ? 'add' : 'del';

    if ($item->{service} eq 'tidal') {
        my $api = Plugins::TIDAL::Plugin::getAPIHandler($client);
        die "no tidal account for this player\n" unless $api;
        $api->updateFavorite(sub { $done->() }, $verb, $item->{type}, $item->{id});
        return;
    }

    if ($item->{service} eq 'qobuz') {
        my $api = Plugins::Qobuz::Plugin::getAPIHandler($client);
        die "no qobuz account for this player\n" unless $api;
        my $sel = { $item->{type} . '_ids' => $item->{id} };
        my $cb  = sub { $done->() };
        if ($verb eq 'add') {
            $api->createFavorite($cb, $sel);
        } else {
            $api->deleteFavorite($cb, $sel);
        }
        return;
    }

    # Spotify: Spotty's API object only wraps ADD operations, so the
    # removal calls go through its generic _call (same request shape).
    if ($item->{service} eq 'spotify') {
        my $api = Plugins::Spotty::Plugin::getAPIHandler($client);
        die "no spotify account for this player\n" unless $api;
        my $id  = $item->{id};
        my $cb  = sub { $done->() };
        my $meth = $verb eq 'add' ? 'PUT' : 'DELETE';
        if ($item->{type} eq 'artist') {
            $api->_call('me/following', $cb, $meth => { ids => $id, type => 'artist' });
        } elsif ($item->{type} eq 'album') {
            $api->_call('me/albums', $cb, $meth => { ids => $id });
        } else {
            $api->_call('me/tracks', $cb, $meth => { ids => $id });
        }
        return;
    }

    die "unsupported service\n";
}

sub _playQueueCleared {

    my $request = shift;
    my $client  = $request->client();
    return if !$client || !$prefs->get('setPlayerLibrary');

    my $prevLib = $prefs->client($client)->get('libraryId');
    return unless $prevLib;

    my $currentLib = $serverprefs->client($client)->get('libraryId') || '';
    if ($currentLib ne $prevLib) {
        $serverprefs->client($client)->set('libraryId', $prevLib);
        Slim::Utils::Timers::setTimer($client, Time::HiRes::time() + 0.1, sub {
            Slim::Schema->totals($client);
        });
    }
    $prefs->client($client)->remove('libraryId');
}

# ---------------------------------------------------------------- queue sorting
#
# Order codes match the queue sort menu in Material:
#   0 reverse   1 shuffle   2 album artist   3 artist   4 album   5 title
#   6 genre     7 year      8 composer       9 conductor  10 band
#  11 date added  12 last played  13 rating  14 play count
# Adding 100 to the code sorts on the first field only.

sub _startsWith {
    return substr($_[0] || '', 0, length($_[1])) eq $_[1];
}

sub _namesort {
    my $param = shift;
    return (!$param || !$param->namesort) ? '' : lc($param->namesort);
}

sub _albumartistsort {
    my $param = shift;
    return (!$param || !$param->contributor) ? '' : _namesort($param->contributor);
}

sub _titlesort {
    my $param = shift;
    return lc($param->titlesort || '');
}


# Primary comparator per order code, plus which tie-breaker profile to append.
#   na = album name, disc, track
#   an = album artist, album name, disc, track
#   nf = album name, album artist, disc, track
my %SORT_SPEC = (
     2 => [ sub { _albumartistsort($a->album) cmp _albumartistsort($b->album) }, 'an' ],
     3 => [ sub { _namesort($a->artist)        cmp _namesort($b->artist) },        'na' ],
     4 => [ sub { _namesort($a->album)         cmp _namesort($b->album) },         'nf' ],
     5 => [ sub { _titlesort($a)               cmp _titlesort($b) },               'an' ],
     6 => [ sub { _namesort($a->genre)         cmp _namesort($b->genre) },         'na' ],
     7 => [ sub { ($a->year      || 0) <=> ($b->year      || 0) },                 'an' ],
     8 => [ sub { _namesort($a->composer)      cmp _namesort($b->composer) },      'na' ],
     9 => [ sub { _namesort($a->conductor)     cmp _namesort($b->conductor) },     'na' ],
    10 => [ sub { _namesort($a->band)          cmp _namesort($b->band) },          'na' ],
    11 => [ sub { ($a->addedTime || 0) <=> ($b->addedTime || 0) },                 'an' ],
    12 => [ sub { ($b->lastplayed || 0) <=> ($a->lastplayed || 0) },               'an' ],
    13 => [ sub { ($a->rating    || 0) <=> ($b->rating    || 0) },                 'an' ],
    14 => [ sub { ($b->playcount || 0) <=> ($a->playcount || 0) },                 'an' ],
);

sub _sortTracks {
    my ($tracksRef, $order) = @_;

    my @tracks = @$tracksRef;
    $order = 0 unless defined $order && $order =~ /^[0-9]+$/;

    my $singleField = 0;
    if ($order >= 100) {
        $order -= 100;
        $singleField = 1;
    }

    return reverse(@tracks) if $order == 0;
    return shuffle(shuffle(@tracks)) if $order == 1;

    my $spec = $SORT_SPEC{$order} or return @tracks;
    my $cmp  = $spec->[0];

    if ($singleField) {
        return sort { $cmp->($a, $b) } @tracks;
    }

    my $tie = $spec->[1];
    return sort {
        my $r = $cmp->($a, $b);
        if (!$r) {
            if ($tie eq 'an') {
                $r = _albumartistsort($a->album) cmp _albumartistsort($b->album)
                  || _namesort($a->album)        cmp _namesort($b->album);
            } elsif ($tie eq 'nf') {
                $r = _namesort($a->album)        cmp _namesort($b->album)
                  || _albumartistsort($a->album) cmp _albumartistsort($b->album);
            } else {
                $r = _namesort($a->album) cmp _namesort($b->album);
            }
            $r ||= ($a->disc     || 0) <=> ($b->disc     || 0)
                || ($a->tracknum || 0) <=> ($b->tracknum || 0);
        }
        $r;
    } @tracks;
}

1;

__END__
